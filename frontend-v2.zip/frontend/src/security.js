// ======================================================================
//  SECURITY HELPERS (frontend only)
//  Honest note: code running in the browser can always be changed by a
//  determined user (DevTools). These helpers stop normal misuse, mistakes
//  and casual cheating. Real enforcement comes with the backend.
// ======================================================================
import { LIMITS, BANNED_WORDS } from './constants'

// ---------- cleaning & validation ----------
export const clean = (s, max = 100) =>
  String(s ?? '').replace(/[<>`]/g, '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max)

export const cleanLong = (s, max = 500) =>
  String(s ?? '').replace(/[<>`]/g, '').replace(/[\u0000-\u0009\u000b-\u001f\u007f]/g, ' ').replace(/[ \t]+/g, ' ').trim().slice(0, max)

export const validName = s => /^[\p{L}][\p{L}\p{M} .'-]{1,39}$/u.test(s)
export const validPhone = p => /^[6-9]\d{9}$/.test(p)

// returns an integer in [min,max] or null
export const toInt = (v, min, max) => {
  const n = Number(v)
  return Number.isFinite(n) && n >= min && n <= max ? Math.floor(n) : null
}

export const isBanned = text => {
  const t = ` ${String(text).toLowerCase()} `
  return BANNED_WORDS.some(w => t.includes(w))
}

// ---------- privacy: show less ----------
export const maskPhone = p => (p && p.length === 10 ? `${p.slice(0, 2)}••••••${p.slice(-2)}` : '')
export const shortName = n => {
  const parts = String(n || '').trim().split(/\s+/)
  return parts.length > 1 ? `${parts[0]} ${parts[1][0].toUpperCase()}.` : parts[0] || 'Customer'
}

// ---------- ids ----------
const rand = n => { const a = new Uint8Array(n); crypto.getRandomValues(a); return a }
export const randPin = () => {
  const a = new Uint32Array(1); crypto.getRandomValues(a)
  return String(1000 + (a[0] % 9000))
}
export const deviceId = () => {
  let id = localStorage.getItem('vg_device')
  if (!id) { id = [...rand(12)].map(b => b.toString(16).padStart(2, '0')).join(''); localStorage.setItem('vg_device', id) }
  return id
}
export const today = () => new Date().toLocaleDateString('en-CA') // YYYY-MM-DD

// ---------- SHA-256 (pure JS, works on http://192.168.x.x too, where crypto.subtle is missing) ----------
const K = []
{ let n = 2; while (K.length < 64) { let p = true; for (let i = 2; i * i <= n; i++) if (n % i === 0) { p = false; break } if (p) K.push(Math.floor((Math.cbrt(n) % 1) * 4294967296)); n++ } }
const H0 = []
{ let n = 2; while (H0.length < 8) { let p = true; for (let i = 2; i * i <= n; i++) if (n % i === 0) { p = false; break } if (p) H0.push(Math.floor((Math.sqrt(n) % 1) * 4294967296)); n++ } }

export function sha256(str) {
  const bytes = new TextEncoder().encode(str)
  const l = bytes.length
  const padLen = ((l + 9 + 63) >> 6) << 6
  const buf = new Uint8Array(padLen); buf.set(bytes); buf[l] = 0x80
  const dv = new DataView(buf.buffer)
  dv.setUint32(padLen - 4, (l * 8) >>> 0); dv.setUint32(padLen - 8, Math.floor((l * 8) / 4294967296))
  const h = new Uint32Array(H0); const w = new Uint32Array(64)
  const rr = (x, n) => (x >>> n) | (x << (32 - n))
  for (let i = 0; i < padLen; i += 64) {
    for (let j = 0; j < 16; j++) w[j] = dv.getUint32(i + j * 4)
    for (let j = 16; j < 64; j++) {
      const s0 = rr(w[j - 15], 7) ^ rr(w[j - 15], 18) ^ (w[j - 15] >>> 3)
      const s1 = rr(w[j - 2], 17) ^ rr(w[j - 2], 19) ^ (w[j - 2] >>> 10)
      w[j] = (w[j - 16] + s0 + w[j - 7] + s1) >>> 0
    }
    let [a, b, c, d, e, f, g, hh] = h
    for (let j = 0; j < 64; j++) {
      const S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25)
      const t1 = (hh + S1 + ((e & f) ^ (~e & g)) + K[j] + w[j]) >>> 0
      const S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22)
      const t2 = (S0 + ((a & b) ^ (a & c) ^ (b & c))) >>> 0
      hh = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0
    }
    h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += hh
  }
  return [...h].map(x => (x >>> 0).toString(16).padStart(8, '0')).join('')
}

// ---------- OTP / login rate limiting (per phone number) ----------
const RL = 'vg_rl'
const rlAll = () => { try { return JSON.parse(localStorage.getItem(RL)) || {} } catch { return {} } }
const rlSave = o => { try { localStorage.setItem(RL, JSON.stringify(o)) } catch { /* ignore */ } }

export function otpCanSend(phone) {
  const now = Date.now(); const r = rlAll()[phone] || {}
  if (r.lockUntil > now) return { ok: false, wait: Math.ceil((r.lockUntil - now) / 1000), why: 'locked' }
  const sent = (r.sent || []).filter(t => now - t < 3600e3)
  if (sent.length >= LIMITS.otpPerHour) return { ok: false, wait: Math.ceil((sent[0] + 3600e3 - now) / 1000), why: 'hour' }
  const last = sent[sent.length - 1]
  if (last && now - last < LIMITS.otpCooldownSec * 1000) return { ok: false, wait: Math.ceil((LIMITS.otpCooldownSec * 1000 - (now - last)) / 1000), why: 'cooldown' }
  return { ok: true }
}
export function otpMarkSent(phone) {
  const all = rlAll(); const r = all[phone] || {}
  r.sent = [...(r.sent || []).filter(t => Date.now() - t < 3600e3), Date.now()]
  all[phone] = r; rlSave(all)
}
export function otpFail(phone) {
  const all = rlAll(); const r = all[phone] || {}
  r.fails = (r.fails || 0) + 1
  let locked = false
  if (r.fails >= LIMITS.otpMaxFails) { r.lockUntil = Date.now() + LIMITS.otpLockMin * 60e3; r.fails = 0; locked = true }
  all[phone] = r; rlSave(all)
  return { locked, left: LIMITS.otpMaxFails - r.fails }
}
export function otpClear(phone) {
  const all = rlAll(); if (all[phone]) { all[phone].fails = 0; delete all[phone].lockUntil; rlSave(all) }
}

// ---------- photo upload: validate, resize, re-encode (this also strips GPS/EXIF data) ----------
export function processImage(file, maxSide = 640) {
  return new Promise((resolve, reject) => {
    if (!file) return reject(new Error('No file'))
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) return reject(new Error('Use a JPG, PNG or WebP photo'))
    if (file.size > 8 * 1024 * 1024) return reject(new Error('Photo is too big (max 8 MB)'))
    const url = URL.createObjectURL(file)
    const img = new Image()
    img.onload = () => {
      URL.revokeObjectURL(url)
      if (!img.width || !img.height || img.width > 12000 || img.height > 12000) return reject(new Error('Unsupported photo size'))
      const s = Math.min(1, maxSide / Math.max(img.width, img.height))
      const c = document.createElement('canvas')
      c.width = Math.max(1, Math.round(img.width * s)); c.height = Math.max(1, Math.round(img.height * s))
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height)
      resolve(c.toDataURL('image/jpeg', 0.72))
    }
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('This file is not a valid photo')) }
    img.src = url
  })
}
