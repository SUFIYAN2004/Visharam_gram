// ====== EDIT THIS FILE: mosques and starting ads ======
// Times are 24-hour "HH:MM". These are PLACEHOLDERS. Fill in the real
// jamaat times from each mosque's notice board.
export const mosques = [
  { id: 1, name: 'Mosque 1 (edit name)', area: 'Main Bazaar', jumuah: '13:15',
    times: { fajr: '05:15', dhuhr: '13:00', asr: '16:30', maghrib: '18:20', isha: '19:45' } },
  { id: 2, name: 'Mosque 2 (edit name)', area: 'Bus Stand Road', jumuah: '13:30',
    times: { fajr: '05:20', dhuhr: '13:05', asr: '16:35', maghrib: '18:20', isha: '19:50' } },
  { id: 3, name: 'Mosque 3 (edit name)', area: 'Market Street', jumuah: '13:00',
    times: { fajr: '05:10', dhuhr: '12:55', asr: '16:25', maghrib: '18:20', isha: '19:40' } },
]

// Starting ads. After the first run, ads are managed from the Admin panel (More tab).
export const seedAds = [
  { id: 1, title: 'Advertise your shop here', text: 'Reach everyone in Melvisharam. Call 90000 00000', cta: 'Contact us', c1: '#0e1f45', c2: '#2b4a9a', active: true },
  { id: 2, title: 'Welcome to Vishram Gram', text: "Melvisharam's own delivery app. Shops, doctors and salons in one place", cta: 'Explore', c1: '#b8862b', c2: '#e0b85c', active: true },
  { id: 3, title: 'Doctors & salons are live', text: 'Check who is available and book your token from home', cta: 'Book now', c1: '#0f766e', c2: '#34d399', active: true },
]

// ====== helpers (no need to edit) ======
export const PRAYERS = [['fajr', 'Fajr'], ['dhuhr', 'Dhuhr'], ['asr', 'Asr'], ['maghrib', 'Maghrib'], ['isha', 'Isha']]

export const fmt12 = hhmm => {
  const [h, m] = hhmm.split(':').map(Number)
  return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`
}

export function nextPrayer(times, now = new Date()) {
  const mins = now.getHours() * 60 + now.getMinutes()
  for (const [key, label] of PRAYERS) {
    const [h, m] = times[key].split(':').map(Number)
    if (h * 60 + m > mins) return { key, label, time: times[key], left: h * 60 + m - mins }
  }
  const [h, m] = times.fajr.split(':').map(Number)
  return { key: 'fajr', label: 'Fajr', time: times.fajr, left: 24 * 60 - mins + h * 60 + m }
}

export const fmtLeft = m => (m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m} min`)
