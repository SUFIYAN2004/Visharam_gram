const img = (seed, w = 600, h = 600) => `https://picsum.photos/seed/${seed}/${w}/${h}`

export const shops = [
  { id: 1, name: 'Fresh Mart',    cat: 'Grocery',     bio: 'Fresh veggies & daily needs', logo: img('freshmart', 200, 200), followers: 340 },
  { id: 2, name: 'City Medicals', cat: 'Medical',     bio: 'Medicines, 8am to 11pm',       logo: img('citymed', 200, 200),   followers: 210 },
  { id: 3, name: 'Hot Bakes',     cat: 'Bakery',      bio: 'Baked fresh every hour',       logo: img('hotbakes', 200, 200),  followers: 520 },
  { id: 4, name: 'Mobile Hub',    cat: 'Electronics', bio: 'Chargers, cases & more',       logo: img('mobilehub', 200, 200), followers: 150 },
]

export const initialPosts = [
  { id: 1, shop: 1, name: 'Ponni Rice 1kg',     price: 60,  stock: 50,  likes: 12, cap: 'Premium ponni rice, just in!',      img: img('rice') },
  { id: 2, shop: 1, name: 'Fresh Milk 500ml',   price: 28,  stock: 40,  likes: 30, cap: 'Delivered with the morning rush',   img: img('milk') },
  { id: 3, shop: 2, name: 'Paracetamol strip',  price: 20,  stock: 100, likes: 5,  cap: 'Fever? We deliver in 10 minutes',   img: img('tablet') },
  { id: 4, shop: 3, name: 'Veg Puff',           price: 15,  stock: 25,  likes: 48, cap: 'Hot out of the oven 🔥',            img: img('puff') },
  { id: 5, shop: 3, name: 'Birthday Cake 500g', price: 350, stock: 5,   likes: 77, cap: 'Order before 6pm for tonight!',     img: img('cake') },
  { id: 6, shop: 4, name: 'Phone Charger 20W',  price: 199, stock: 15,  likes: 9,  cap: 'Fast charging, 6 month warranty',   img: img('charger') },
  { id: 7, shop: 4, name: 'Bass Earphones',     price: 249, stock: 10,  likes: 21, cap: 'Bass boosted',                      img: img('earphone') },
]