import { useState, useEffect, useRef, useCallback } from 'react'
import { shops as seedShops, initialPosts } from './data/mock'
import { seedAds } from './data/static'
import { LIMITS, ACTIVE } from './constants'
import { randPin, today, deviceId } from './security'

const KEY = 'vg_db'
const SESSION = 'vg_session2'
const VERSION = 2

const prov = (id, type, name, tag, fee, address, phone, avgMin, available) => ({
  id, userId: null, type, name, tag, fee, address, phone, avgMin, available,
  serving: 0, nextToken: 1, day: today(),
})

function makeSeed() {
  return {
    version: VERSION,
    users: [],
    shops: seedShops.map(s => ({ ...s, owner: null })),
    posts: initialPosts.map(p => ({ ...p })),
    orders: [],
    follows: {}, liked: {},
    providers: [
      prov(1, 'doctor', 'Demo Clinic', 'General Physician', 150, 'Main Road', '9000000011', 10, true),
      prov(2, 'doctor', 'Demo Child Care', 'Child Specialist', 250, 'Bus Stand Road', '9000000012', 15, false),
      prov(3, 'salon', 'Demo Gents Salon', 'Haircut · Beard · Facial', 80, 'Market Street', '9000000013', 20, true),
      prov(4, 'salon', 'Demo Beauty Parlour', 'Ladies · Threading · Bridal', 100, 'Main Bazaar', '9000000014', 25, true),
    ],
    bookings: [],
    reports: [],        // reports sent to the developer
    blocks: [],         // {by, target}: user-to-user blocks
    blockedPhones: [],  // {phone, reason, ts}
    blockedDevices: [], // device ids of blocked accounts
    audit: [],          // security / admin log
    ads: seedAds.map(a => ({ ...a })),
    nextOrder: 1, nextPost: 1000, nextShop: 100, nextUser: 1, nextProvider: 100,
    nextBooking: 1, nextReport: 1, nextAd: 100,
  }
}

function migrate(saved) {
  const base = makeSeed()
  const d = { ...base, ...saved }
  for (const k of ['users', 'orders', 'bookings', 'reports', 'blocks', 'blockedPhones', 'blockedDevices', 'audit', 'ads', 'shops', 'posts', 'providers']) {
    if (!Array.isArray(d[k])) d[k] = base[k]
  }
  if (!d.follows || typeof d.follows !== 'object') d.follows = {}
  if (!d.liked || typeof d.liked !== 'object') d.liked = {}
  d.users = d.users.map(u => ({ status: 'active', strikes: 0, ...u }))
  d.orders = d.orders.map(o => ({ pin: randPin(), pinTries: 0, settled: false, area: '', ...o }))
  d.providers = d.providers.map(p => ({ day: today(), ...p }))
  d.version = VERSION
  return d
}

function load() {
  try {
    const raw = localStorage.getItem(KEY)
    return raw ? migrate(JSON.parse(raw)) : makeSeed()
  } catch { return makeSeed() }
}

// ---------- helpers used by every screen ----------
export function log(d, type, text, actor = 0) {
  d.audit.unshift({ ts: Date.now(), type, text: String(text).slice(0, 200), actor })
  if (d.audit.length > 300) d.audit.length = 300
}

export const isBlockedBetween = (db, a, b) =>
  !!a && !!b && db.blocks.some(x => (x.by === a && x.target === b) || (x.by === b && x.target === a))

export function toggleBlock(d, by, target) {
  const i = d.blocks.findIndex(x => x.by === by && x.target === target)
  if (i > -1) { d.blocks.splice(i, 1); return false }
  d.blocks.push({ by, target, ts: Date.now() }); return true
}

const ownerOk = (db, ownerId, viewerId) => {
  if (!ownerId) return true // sample shop with no owner yet
  const o = db.users.find(u => u.id === ownerId)
  return !!o && o.status === 'active' && !isBlockedBetween(db, viewerId, ownerId)
}
export const visibleShops = (db, viewerId) => db.shops.filter(s => ownerOk(db, s.owner, viewerId))
export const visibleProviders = (db, viewerId) => db.providers.filter(p => ownerOk(db, p.userId, viewerId))

export function strike(d, userId, reason) {
  const u = d.users.find(x => x.id === userId)
  if (!u || u.role === 'admin') return
  u.strikes = (u.strikes || 0) + 1
  log(d, 'strike', `${u.name} got strike ${u.strikes}: ${reason}`, 0)
  if (u.strikes >= LIMITS.strikesToReview && u.status === 'active') {
    u.status = 'review'; u.statusReason = 'Too many missed or failed orders'
    log(d, 'review', `${u.name} paused for review (strikes)`, 0)
  }
}

// ----- reports to the developer -----
export function checkReport(db, p) {
  if (!p.reason) return 'Choose a reason'
  if ((p.text || '').length > 500) return 'Please keep it under 500 characters'
  const dayAgo = Date.now() - 864e5
  if (db.reports.filter(r => r.from === p.from && r.ts > dayAgo && !r.system).length >= LIMITS.maxReportsPerDay)
    return `You can send ${LIMITS.maxReportsPerDay} reports a day`
  if (p.target && db.reports.some(r => r.from === p.from && r.target === p.target && r.orderId === (p.orderId || null) && r.status === 'open'))
    return 'You already reported this. The developer will look at it.'
  return null
}

export function addReport(d, p) {
  const r = {
    id: d.nextReport++, ts: Date.now(), from: p.from, kind: p.kind, target: p.target || null,
    orderId: p.orderId || null, reason: p.reason, text: p.text || '', status: 'open', system: !!p.system, note: '',
  }
  d.reports.unshift(r)
  log(d, 'report', `Report #${r.id}: ${r.reason}`, p.from)
  // many different people reporting one account -> pause it until the developer checks
  if (p.target && !p.system) {
    const weekAgo = Date.now() - 7 * 864e5
    const who = new Set(d.reports.filter(x => x.target === p.target && x.status === 'open' && !x.system && x.ts > weekAgo).map(x => x.from))
    const t = d.users.find(u => u.id === p.target)
    if (t && t.role !== 'admin' && t.status === 'active' && who.size >= LIMITS.reviewAtReports) {
      t.status = 'review'; t.statusReason = 'Several reports. Under review by the developer'
      log(d, 'review', `${t.name} paused for review (${who.size} reporters)`, 0)
    }
  }
  return r
}

// ----- runs on load and every 30 seconds: expire old orders / tokens, new-day reset -----
export function maintain(d) {
  let changed = false
  const now = Date.now(); const day = today()
  for (const o of d.orders) {
    if (o.status === 'placed' && now - o.time > LIMITS.placedExpiryMin * 60e3) { o.status = 'expired'; changed = true }
  }
  for (const p of d.providers) {
    if (p.day !== day) { p.day = day; p.serving = 0; p.nextToken = 1; p.available = false; changed = true }
  }
  for (const b of d.bookings) {
    if ((b.status === 'waiting' || b.status === 'serving') && b.day !== day) { b.status = 'expired'; changed = true }
  }
  return changed ? undefined : false
}

export const activeOrdersOf = (db, userId) => db.orders.filter(o => o.customer === userId && ACTIVE.includes(o.status))

// ---------- the hook ----------
const readSession = () => {
  try {
    const s = JSON.parse(localStorage.getItem(SESSION))
    if (!s || Date.now() - s.ts > LIMITS.sessionDays * 864e5) return null
    return s
  } catch { return null }
}

export function useStore() {
  const [db, setDb] = useState(() => { const d = load(); maintain(d); return d })
  const [userId, setUserId] = useState(() => readSession()?.id || null)
  const lastActive = useRef(Date.now())

  // save + keep other open tabs in sync
  useEffect(() => {
    try { localStorage.setItem(KEY, JSON.stringify(db)) }
    catch { alert('Phone storage is full. Use smaller photos, or delete old products.') }
  }, [db])
  useEffect(() => {
    const onStorage = e => { if (e.key === KEY && e.newValue) { try { setDb(migrate(JSON.parse(e.newValue))) } catch { /* ignore */ } } }
    addEventListener('storage', onStorage)
    return () => removeEventListener('storage', onStorage)
  }, [])

  const update = useCallback(fn => setDb(prev => {
    const d = structuredClone(prev)
    return fn(d) === false ? prev : d
  }), [])

  // 30 second housekeeping
  useEffect(() => {
    const t = setInterval(() => update(maintain), 30000)
    return () => clearInterval(t)
  }, [update])

  const login = useCallback(id => {
    localStorage.setItem(SESSION, JSON.stringify({ id, ts: Date.now() }))
    lastActive.current = Date.now(); setUserId(id)
  }, [])
  const logout = useCallback(() => { localStorage.removeItem(SESSION); setUserId(null) }, [])

  const user = db.users.find(u => u.id === userId) || null

  // removed or blocked users are logged out; admin sessions end after 15 idle minutes
  useEffect(() => { if (userId && !user) logout() }, [userId, user, logout])
  useEffect(() => {
    const touch = () => { lastActive.current = Date.now() }
    for (const ev of ['pointerdown', 'keydown']) addEventListener(ev, touch, { passive: true })
    const t = setInterval(() => {
      if (user?.role === 'admin' && Date.now() - lastActive.current > LIMITS.adminIdleMin * 60e3) logout()
    }, 20000)
    return () => { for (const ev of ['pointerdown', 'keydown']) removeEventListener(ev, touch); clearInterval(t) }
  }, [user?.role, logout])

  return { db, update, user, login, logout, device: deviceId() }
}
