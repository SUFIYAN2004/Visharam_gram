import { useState, useMemo } from 'react'
import PostCard from '../components/PostCard'
import BottomNav from '../components/BottomNav'
import AdBanner from '../components/AdBanner'
import { ActionSheet } from '../components/Sheet'
import ReportSheet from '../components/ReportSheet'
import Profile from './Profile'
import Services from './Services'
import { Toast, useToast } from '../components/Toast'
import { STEPS, LABEL, DEAD, ACTIVE, DELIVERY_FEE, AREAS, LIMITS } from '../constants'
import { mosques, nextPrayer, fmt12, fmtLeft } from '../data/static'
import { clean, randPin, maskPhone } from '../security'
import { visibleShops, isBlockedBetween, toggleBlock, log } from '../store'

export default function Customer({ db, update, user, logout }) {
  const [tab, setTab] = useState('home')
  const [svc, setSvc] = useState('doctor')
  const [openShop, setOpenShop] = useState(null)
  const [feed, setFeed] = useState('foryou')
  const [cart, setCart] = useState({})
  const [query, setQuery] = useState('')
  const [addr, setAddr] = useState(user.savedAddress || { area: '', details: '', landmark: '' })
  const [menu, setMenu] = useState(null)     // action sheet
  const [report, setReport] = useState(null) // report sheet
  const [toast, showToast] = useToast()

  const shops = useMemo(() => visibleShops(db, user.id), [db, user.id])
  const shopIds = new Set(shops.map(s => s.id))
  const posts = db.posts.filter(p => shopIds.has(p.shop))
  const liked = db.liked[user.id] || []
  const follows = db.follows[user.id] || []
  const myOrders = db.orders.filter(o => o.customer === user.id)
  const myTokens = db.bookings.filter(b => b.customer === user.id && (b.status === 'waiting' || b.status === 'serving')).length
  const shopOf = id => db.shops.find(s => s.id === id)
  const postOf = id => posts.find(p => p.id === id)
  const cartCount = Object.values(cart).reduce((a, b) => a + b, 0)
  const me = db.users.find(u => u.id === user.id)

  const toggleList = (key, id) => update(d => {
    const list = (d[key][user.id] ||= [])
    const i = list.indexOf(id)
    if (i > -1) list.splice(i, 1); else list.push(id)
  })

  const addToCart = p => {
    const have = cart[p.id] || 0
    if (have >= p.stock) return showToast('No more stock')
    if (have >= LIMITS.maxQtyPerItem) return showToast(`Maximum ${LIMITS.maxQtyPerItem} of one item`)
    setCart({ ...cart, [p.id]: have + 1 })
    showToast(`${p.name} added`)
  }
  const changeQty = (id, d) => {
    const p = postOf(id); if (!p) return
    const q = (cart[id] || 0) + d
    const next = { ...cart }
    if (q <= 0) delete next[id]
    else if (q <= p.stock && q <= LIMITS.maxQtyPerItem) next[id] = q
    else showToast(q > p.stock ? 'No more stock' : `Maximum ${LIMITS.maxQtyPerItem} of one item`)
    setCart(next)
  }

  const placeOrder = () => {
    if (me.status !== 'active') return showToast('Your account is under review')
    const items = Object.entries(cart).map(([id, q]) => ({ p: postOf(+id), q })).filter(x => x.p && x.q > 0)
    if (!items.length) return showToast('Your cart is empty')
    if (!addr.area) return showToast('Choose your area')
    const details = clean(addr.details, 160)
    if (details.length < 8) return showToast('Enter house number and street')
    const landmark = clean(addr.landmark, 80)

    for (const { p, q } of items) if (q > p.stock) return showToast(`Only ${p.stock} left of ${p.name}`)

    const byShop = {}
    items.forEach(({ p, q }) => { (byShop[p.shop] ??= []).push({ pid: p.id, name: p.name, price: p.price, qty: q }) })
    const shopCount = Object.keys(byShop).length

    const active = myOrders.filter(o => ACTIVE.includes(o.status)).length
    if (active + shopCount > LIMITS.maxActiveOrders) return showToast(`You can have ${LIMITS.maxActiveOrders} active orders at a time`)
    if (myOrders[0] && Date.now() - myOrders[0].time < LIMITS.orderCooldownMs) return showToast('Please wait a few seconds before ordering again')

    const sub = items.reduce((t, x) => t + x.p.price * x.q, 0)
    if (!myOrders.some(o => o.status === 'delivered') && sub > LIMITS.firstOrderMax)
      return showToast(`Your first order can be up to ₹${LIMITS.firstOrderMax}`)

    for (const sid of Object.keys(byShop)) {
      const s = shopOf(+sid)
      if (!s || (s.owner && isBlockedBetween(db, user.id, s.owner))) return showToast('This shop cannot take your order')
    }

    update(d => {
      const u = d.users.find(x => x.id === user.id); u.savedAddress = { area: addr.area, details, landmark }
      Object.entries(byShop).forEach(([shop, its]) => {
        d.orders.unshift({
          id: d.nextOrder++, customer: user.id, shop: +shop, rider: null, items: its,
          area: addr.area, address: details, landmark, phone: me.phone,
          fee: DELIVERY_FEE, total: its.reduce((t, x) => t + x.price * x.qty, 0) + DELIVERY_FEE,
          payment: 'COD', status: 'placed', time: Date.now(), pin: randPin(), pinTries: 0, settled: false,
        })
      })
    })
    setCart({}); setTab('orders'); showToast('Order placed! Pay cash on delivery')
  }

  const cancelOrder = id => {
    if (!confirm('Cancel this order?')) return
    update(d => {
      const o = d.orders.find(x => x.id === id)
      if (!o || o.customer !== user.id || o.status !== 'placed') return false
      o.status = 'cancelled'; log(d, 'order', `Order #${id} cancelled by customer`, user.id)
    })
  }

  const ownerOf = shopId => shopOf(shopId)?.owner || null

  const reportShop = s => s.owner && setReport({ targets: [{ userId: s.owner, label: s.name, kind: 'shop' }] })
  const blockShop = s => {
    if (!s.owner) return
    if (confirm(`Block ${s.name}? You will no longer see this shop, and it cannot see you.`)) {
      update(d => { toggleBlock(d, user.id, s.owner) }); setOpenShop(null); showToast('Shop blocked. You can undo it in Profile')
    }
  }
  const orderTargets = o => {
    const t = []
    const s = shopOf(o.shop); if (s?.owner) t.push({ userId: s.owner, label: s.name, kind: 'shop' })
    if (o.rider) { const r = db.users.find(u => u.id === o.rider); if (r) t.push({ userId: r.id, label: `Rider ${r.name}`, kind: 'rider' }) }
    return t
  }

  const card = p => (
    <PostCard key={p.id} p={p} shop={shopOf(p.shop)}
      liked={liked.includes(p.id)} qty={cart[p.id]}
      onLike={() => toggleList('liked', p.id)} onAdd={() => addToCart(p)}
      onShop={() => { setOpenShop(p.shop); setTab('home') }} />
  )

  // ---------------- HOME ----------------
  const Home = () => {
    if (openShop && shopIds.has(openShop)) {
      const s = shopOf(openShop)
      const sp = posts.filter(p => p.shop === openShop)
      const f = follows.includes(openShop)
      return (
        <>
          <div className="flex items-center justify-between">
            <button onClick={() => setOpenShop(null)} className="m-3 text-sm font-semibold min-h-11">← Back</button>
            {s.owner && (
              <button aria-label="More options" className="m-3 w-11 h-11 text-xl"
                onClick={() => setMenu({ title: s.name, actions: [{ label: '🚩 Report this shop', onClick: () => reportShop(s) }, { label: '⛔ Block this shop', danger: true, onClick: () => blockShop(s) }] })}>⋯</button>
            )}
          </div>
          <div className="bg-white px-4 pb-4">
            <div className="flex items-center gap-5">
              <img src={s.logo} alt="" className="w-20 h-20 rounded-full object-cover" />
              <div className="flex gap-6 text-center text-sm">
                <div><b>{sp.length}</b><br />posts</div>
                <div><b>{s.followers + (f ? 1 : 0)}</b><br />followers</div>
              </div>
            </div>
            <p className="font-semibold mt-3">{s.name}</p>
            <p className="text-sm text-gray-500 wrap-any">{s.cat} · {s.bio}</p>
            <button onClick={() => toggleList('follows', openShop)}
              className={`mt-3 w-full min-h-11 rounded-lg font-semibold text-sm ${f ? 'bg-gray-200' : 'bg-[#0e1f45] text-white'}`}>{f ? 'Following' : 'Follow'}</button>
          </div>
          <div className="mt-3">{sp.map(card)}</div>
        </>
      )
    }
    const list = feed === 'following' ? posts.filter(p => follows.includes(p.shop)) : posts
    const m = mosques[0]; const np = m ? nextPrayer(m.times) : null
    return (
      <>
        {me.status === 'review' && (
          <p className="mx-3 mt-3 text-sm bg-amber-50 text-amber-800 rounded-xl p-3">⚠️ Your account is under review ({me.statusReason || 'please wait'}). You can browse but cannot order yet. Contact the developer from Profile.</p>
        )}
        <AdBanner ads={db.ads} />
        {np && (
          <button onClick={() => { setSvc('namaz'); setTab('services') }}
            className="mx-3 mt-3 w-[calc(100%-1.5rem)] bg-white rounded-xl px-4 py-3 flex items-center justify-between text-left shadow-sm min-h-11">
            <span className="text-sm truncate"><b>🕌 {np.label}</b> · {fmt12(np.time)} <span className="text-gray-500">at {m.name}</span></span>
            <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full whitespace-nowrap ml-2">in {fmtLeft(np.left)}</span>
          </button>
        )}
        <div className="flex gap-4 overflow-x-auto no-scrollbar bg-white px-3 py-3 my-3">
          {shops.map(s => (
            <button key={s.id} onClick={() => setOpenShop(s.id)} className="flex-none w-16 text-center">
              <div className="p-[3px] rounded-full bg-gradient-to-tr from-[#e0b85c] via-[#c9973a] to-[#0e1f45]">
                <img src={s.logo} alt="" className="w-full aspect-square rounded-full object-cover border-2 border-white" />
              </div>
              <p className="text-[11px] mt-1 truncate">{s.name.split(' ')[0]}</p>
            </button>
          ))}
        </div>
        <div className="flex bg-white border-b mb-2">
          {[['foryou', 'For You'], ['following', 'Following']].map(([id, l]) => (
            <button key={id} onClick={() => setFeed(id)}
              className={`flex-1 min-h-11 text-sm font-semibold ${feed === id ? 'border-b-2 border-[#0e1f45]' : 'text-gray-400'}`}>{l}</button>
          ))}
        </div>
        {list.length ? list.map(card) : <p className="text-center text-gray-400 py-12 px-6">{feed === 'following' ? 'Follow some shops to see their posts' : 'No shops yet'}</p>}
      </>
    )
  }

  // ---------------- SEARCH ----------------
  const Search = () => {
    const q = clean(query, 40).toLowerCase()
    const r = posts.filter(p => (p.name + shopOf(p.shop).name + shopOf(p.shop).cat).toLowerCase().includes(q))
    return (
      <div className="p-3">
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search products, shops, categories" maxLength={40}
          className="w-full bg-white rounded-xl px-4 py-3 outline-none" />
        <div className="grid grid-cols-3 gap-0.5 mt-3">
          {r.map(p => (
            <button key={p.id} onClick={() => addToCart(p)} className="relative" aria-label={`Add ${p.name}`}>
              <img src={p.img} alt={p.name} loading="lazy" className="aspect-square w-full object-cover bg-gray-100" />
              <span className="absolute bottom-1 right-1 bg-black/70 text-white text-[10px] px-1.5 rounded">₹{p.price}</span>
            </button>
          ))}
        </div>
        {!r.length && <p className="text-center text-gray-400 py-10">Nothing found</p>}
        {!!r.length && <p className="text-xs text-gray-400 mt-2">Tap a photo to add it to the cart</p>}
      </div>
    )
  }

  // ---------------- CART ----------------
  const Cart = () => {
    const items = Object.entries(cart).map(([id, q]) => ({ p: postOf(+id), q })).filter(x => x.p)
    const sub = items.reduce((t, i) => t + i.p.price * i.q, 0)
    const shopCount = new Set(items.map(i => i.p.shop)).size
    const fee = DELIVERY_FEE * shopCount
    if (!items.length) return <p className="text-center text-gray-400 py-20">Your cart is empty 🛒</p>
    return (
      <div className="p-3 space-y-3">
        <h2 className="font-bold text-lg">Your cart</h2>
        <div className="bg-white rounded-xl p-3">
          {items.map(({ p, q }) => (
            <div key={p.id} className="flex items-center gap-3 py-2">
              <img src={p.img} alt="" className="w-14 h-14 rounded-lg object-cover shrink-0" />
              <div className="flex-1 text-sm min-w-0">
                <p className="font-semibold truncate">{p.name}</p>
                <p className="text-gray-500 truncate">{shopOf(p.shop).name} · ₹{p.price}</p>
              </div>
              <div className="flex items-center gap-1">
                <button aria-label="Less" onClick={() => changeQty(p.id, -1)} className="w-9 h-9 rounded-full border">−</button>
                <span className="w-6 text-center">{q}</span>
                <button aria-label="More" onClick={() => changeQty(p.id, 1)} className="w-9 h-9 rounded-full border">+</button>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-xl p-3 space-y-2">
          <p className="font-semibold text-sm">Delivery address</p>
          <select value={addr.area} onChange={e => setAddr({ ...addr, area: e.target.value })} className="w-full border rounded-xl px-3 py-3 bg-white">
            <option value="">Choose your area</option>
            {AREAS.map(a => <option key={a} value={a}>{a}</option>)}
          </select>
          <textarea value={addr.details} onChange={e => setAddr({ ...addr, details: e.target.value })} rows={2} maxLength={160}
            placeholder="House number, street" className="w-full border rounded-xl p-3 outline-none" />
          <input value={addr.landmark} onChange={e => setAddr({ ...addr, landmark: e.target.value })} maxLength={80}
            placeholder="Landmark (optional)" className="w-full border rounded-xl px-3 py-3 outline-none" />
          <p className="text-[11px] text-gray-400">Only the area is shown to riders until they pick up your order.</p>
        </div>

        <div className="bg-white rounded-xl p-3 text-sm space-y-1">
          <div className="flex justify-between"><span>Items</span><span>₹{sub}</span></div>
          <div className="flex justify-between"><span>Delivery fee ({shopCount} shop{shopCount > 1 ? 's' : ''})</span><span>₹{fee}</span></div>
          <div className="flex justify-between font-bold text-base pt-1 border-t"><span>To pay</span><span>₹{sub + fee}</span></div>
        </div>
        <div className="bg-green-50 text-green-700 rounded-xl p-3 text-sm">💵 Payment: Cash on delivery. You will get a 4-digit PIN to confirm delivery.</div>
        <button onClick={placeOrder} className="w-full bg-green-600 text-white font-semibold min-h-12 rounded-xl active:scale-95 transition">Place order · ₹{sub + fee}</button>
      </div>
    )
  }

  // ---------------- ORDERS ----------------
  const Orders = () => (
    <div className="p-3 space-y-3">
      <h2 className="font-bold text-lg">My orders</h2>
      {!myOrders.length && <p className="text-center text-gray-400 py-16">No orders yet</p>}
      {myOrders.map(o => {
        const rider = db.users.find(u => u.id === o.rider)
        const dead = DEAD.includes(o.status)
        const s = shopOf(o.shop)
        return (
          <div key={o.id} className="bg-white rounded-xl p-3">
            <div className="flex justify-between items-start gap-2">
              <b className="min-w-0 truncate">#{o.id} · {s?.name}</b>
              <div className="flex items-center gap-1 shrink-0">
                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${dead ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-700'}`}>{LABEL[o.status]}</span>
                <button aria-label="Order options" className="w-9 h-9 text-lg"
                  onClick={() => setMenu({
                    title: `Order #${o.id}`,
                    actions: [
                      o.status === 'placed' && { label: 'Cancel order', danger: true, onClick: () => cancelOrder(o.id) },
                      { label: '🚩 Report a problem', onClick: () => setReport({ orderId: o.id, targets: orderTargets(o).length ? orderTargets(o) : [] }) },
                    ],
                  })}>⋯</button>
              </div>
            </div>
            {!dead && (
              <div className="flex gap-1 my-3">
                {STEPS.map((st, i) => <div key={st} className={`flex-1 h-1.5 rounded ${i <= STEPS.indexOf(o.status) ? 'bg-green-600' : 'bg-gray-200'}`} />)}
              </div>
            )}
            <p className="text-sm text-gray-600 mt-2">{o.items.map(i => `${i.name} × ${i.qty}`).join(', ')}</p>
            <p className="text-xs text-gray-400 mt-1 wrap-any">📍 {o.area}, {o.address}</p>

            {o.status === 'picked_up' && (
              <div className="mt-3 rounded-xl bg-[#0e1f45] text-white p-3">
                <p className="text-xs opacity-80">Delivery PIN. Tell this to the rider only AFTER you receive your order.</p>
                <p className="text-3xl font-bold tracking-[0.4em] text-[#e0b85c] text-center my-1">{o.pin}</p>
                {rider && (
                  <p className="text-xs opacity-90 text-center">🛵 {rider.name} · {maskPhone(rider.phone)} ·{' '}
                    <a className="underline" href={`tel:${rider.phone}`}>Call</a></p>
                )}
              </div>
            )}
            {o.dispute && <p className="text-xs text-amber-700 bg-amber-50 rounded-lg p-2 mt-2">There was a problem confirming this delivery. The developer has been told and will contact you.</p>}
            <p className="text-sm font-semibold mt-2">₹{o.total} · Cash on delivery</p>
          </div>
        )
      })}
    </div>
  )

  return (
    <>
      {tab === 'home' && Home()}
      {tab === 'search' && Search()}
      {tab === 'services' && <Services key={svc} db={db} update={update} user={user} showToast={showToast} initial={svc} />}
      {tab === 'cart' && Cart()}
      {tab === 'orders' && Orders()}
      {tab === 'profile' && <Profile db={db} update={update} user={me} logout={logout} showToast={showToast} />}
      <Toast msg={toast} />
      {menu && <ActionSheet title={menu.title} actions={menu.actions} onClose={() => setMenu(null)} />}
      {report && <ReportSheet db={db} update={update} user={user} targets={report.targets} orderId={report.orderId} onClose={() => setReport(null)} showToast={showToast} />}
      <BottomNav
        tabs={[['home', 'Home'], ['search', 'Search'], ['services', 'Services'], ['cart', 'Cart'], ['orders', 'Orders'], ['profile', 'Me']]}
        tab={tab} setTab={t => { setTab(t); setOpenShop(null); if (t === 'services') setSvc('doctor') }}
        badges={{ cart: cartCount, services: myTokens }} />
    </>
  )
}
