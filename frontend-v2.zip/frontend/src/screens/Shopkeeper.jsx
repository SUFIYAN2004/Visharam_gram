import { useState } from 'react'
import BottomNav from '../components/BottomNav'
import { ActionSheet } from '../components/Sheet'
import ReportSheet from '../components/ReportSheet'
import Profile from './Profile'
import { Toast, useToast } from '../components/Toast'
import { LABEL, DEAD, LIMITS } from '../constants'
import { clean, toInt, isBanned, shortName, processImage } from '../security'
import { toggleBlock, log } from '../store'

const empty = { name: '', price: '', stock: '', cap: '', img: '' }
const inp = 'w-full border rounded-xl px-4 py-3 outline-none focus:border-[#0e1f45] mb-2'

export default function Shopkeeper({ db, update, user, logout }) {
  const [tab, setTab] = useState('dash')
  const [form, setForm] = useState(empty)
  const [busy, setBusy] = useState(false)
  const [menu, setMenu] = useState(null)
  const [report, setReport] = useState(null)
  const [toast, showToast] = useToast()

  const shop = db.shops.find(s => s.id === user.shopId)
  const orders = db.orders.filter(o => o.shop === shop.id)
  const products = db.posts.filter(p => p.shop === shop.id)
  const pending = orders.filter(o => o.status === 'placed').length
  const delivered = orders.filter(o => o.status === 'delivered')
  const itemsTotal = o => o.total - (o.fee || 0)
  const revenue = delivered.reduce((t, o) => t + itemsTotal(o), 0)
  const unsettled = delivered.filter(o => !o.settled)
  const lowStock = products.filter(p => p.stock <= 5)
  const customerOf = id => db.users.find(u => u.id === id)
  const riderOf = id => db.users.find(u => u.id === id)

  const setStatus = (id, status) => update(d => {
    const o = d.orders.find(x => x.id === id)
    if (!o || o.shop !== shop.id) return false
    const ok = { accepted: o.status === 'placed', rejected: o.status === 'placed', ready: o.status === 'accepted' }[status]
    if (!ok) return false
    if (status === 'accepted') {
      // re-check stock at the moment of accepting
      for (const i of o.items) { const p = d.posts.find(x => x.id === i.pid); if (!p || p.stock < i.qty) return false }
      o.items.forEach(i => { d.posts.find(x => x.id === i.pid).stock -= i.qty })
    }
    o.status = status
  })

  const markReceived = id => update(d => {
    const o = d.orders.find(x => x.id === id)
    if (!o || o.shop !== shop.id || o.status !== 'delivered') return false
    o.settled = true; o.settledAt = Date.now(); log(d, 'cash', `Shop ${shop.name} received cash for order #${id}`, user.id)
  })

  const pickPhoto = async e => {
    const f = e.target.files[0]; e.target.value = ''
    if (!f) return
    try { setBusy(true); setForm(x => ({ ...x, img: '' })); const img = await processImage(f); setForm(x => ({ ...x, img })) }
    catch (err) { showToast(err.message) } finally { setBusy(false) }
  }

  const addProduct = () => {
    const name = clean(form.name, 60); const cap = clean(form.cap, 120)
    const price = toInt(form.price, 1, 100000); const stock = toInt(form.stock || 0, 0, 10000)
    if (name.length < 2) return showToast('Enter the product name')
    if (price === null) return showToast('Price must be between ₹1 and ₹1,00,000')
    if (stock === null) return showToast('Stock must be between 0 and 10,000')
    if (isBanned(name) || isBanned(cap)) return showToast('This item is not allowed on Vishram Gram')
    if (products.length >= LIMITS.maxProductsPerShop) return showToast(`You can list up to ${LIMITS.maxProductsPerShop} products`)
    if (busy) return showToast('Wait for the photo to finish')
    update(d => {
      const id = d.nextPost++
      d.posts.unshift({ id, shop: shop.id, name, price, stock, likes: 0, cap, img: form.img || `https://picsum.photos/seed/p${id}/600/600` })
    })
    setForm(empty); showToast('Posted! Customers can see it now')
  }

  const setStock = (id, v) => { const n = toInt(v, 0, 10000); if (n !== null) update(d => { const p = d.posts.find(x => x.id === id); if (!p || p.shop !== shop.id) return false; p.stock = n }) }
  const removeProduct = id => { if (confirm('Delete this product?')) update(d => { d.posts = d.posts.filter(p => !(p.id === id && p.shop === shop.id)) }) }

  const customerMenu = o => {
    const c = customerOf(o.customer); if (!c) return
    setMenu({ title: `${shortName(c.name)} · order #${o.id}`, actions: [
      { label: '🚩 Report this customer', onClick: () => setReport({ orderId: o.id, targets: [{ userId: c.id, label: shortName(c.name), kind: 'customer' }] }) },
      { label: '⛔ Block this customer', danger: true, onClick: () => { if (confirm('Block this customer? They will not be able to order from you.')) { update(d => { toggleBlock(d, user.id, c.id) }); showToast('Customer blocked') } } },
    ] })
  }

  const OrderCard = o => {
    const c = customerOf(o.customer); const dead = DEAD.includes(o.status)
    return (
      <div key={o.id} className="bg-white rounded-xl p-3">
        <div className="flex justify-between items-center gap-2">
          <b className="truncate">#{o.id} · {shortName(c?.name)}</b>
          <div className="flex items-center gap-1 shrink-0">
            <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${dead ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-700'}`}>{LABEL[o.status]}</span>
            <button aria-label="Options" className="w-9 h-9 text-lg" onClick={() => customerMenu(o)}>⋯</button>
          </div>
        </div>
        <p className="text-sm mt-2">{o.items.map(i => `${i.name} × ${i.qty}`).join(', ')}</p>
        <p className="text-xs text-gray-500 mt-1">Items ₹{itemsTotal(o)} · cash on delivery</p>
        <div className="mt-2 flex gap-2">
          {o.status === 'placed' && <>
            <button onClick={() => setStatus(o.id, 'accepted')} className="flex-1 bg-green-600 text-white min-h-11 rounded-lg text-sm font-semibold">Accept</button>
            <button onClick={() => { if (confirm('Reject this order?')) setStatus(o.id, 'rejected') }} className="flex-1 bg-red-500 text-white min-h-11 rounded-lg text-sm font-semibold">Reject</button>
          </>}
          {o.status === 'accepted' && <button onClick={() => setStatus(o.id, 'ready')} className="flex-1 bg-[#0e1f45] text-white min-h-11 rounded-lg text-sm font-semibold">Mark ready for pickup</button>}
        </div>
      </div>
    )
  }

  const CashPanel = () => unsettled.length > 0 && (
    <div className="bg-white rounded-xl p-3 border-l-4 border-amber-400">
      <p className="font-semibold text-sm">💵 Cash to collect from riders · ₹{unsettled.reduce((t, o) => t + itemsTotal(o), 0)}</p>
      <p className="text-xs text-gray-500 mb-2">Tap "Received" only after the rider hands you the money.</p>
      {unsettled.map(o => {
        const r = riderOf(o.rider)
        const hrs = Math.floor((Date.now() - (o.deliveredAt || o.time)) / 36e5)
        return (
          <div key={o.id} className="flex items-center justify-between gap-2 py-2 border-t">
            <div className="text-sm min-w-0"><p className="font-semibold truncate">#{o.id} · ₹{itemsTotal(o)}</p>
              <p className={`text-xs ${hrs >= LIMITS.cashOverdueHours ? 'text-red-600 font-semibold' : 'text-gray-500'}`}>Rider {r?.name || '-'} · {hrs}h ago{hrs >= LIMITS.cashOverdueHours ? ' · OVERDUE' : ''}</p></div>
            <button onClick={() => markReceived(o.id)} className="bg-green-600 text-white text-sm px-4 min-h-11 rounded-lg shrink-0">Received</button>
          </div>
        )
      })}
    </div>
  )

  const Dash = () => (
    <div className="p-3 space-y-3">
      <div className="flex items-center gap-3">
        <img src={shop.logo} alt="" className="w-12 h-12 rounded-full object-cover" />
        <div className="min-w-0"><p className="text-xs text-gray-500">Welcome back, {user.name}</p><p className="font-bold truncate">{shop.name}</p></div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {[['New orders', pending, 'text-orange-600'], ['Total orders', orders.length, ''], ['Revenue', `₹${revenue}`, 'text-green-700'], ['Products', products.length, '']].map(([l, v, c]) => (
          <div key={l} className="bg-white rounded-xl p-3"><p className="text-xs text-gray-500">{l}</p><p className={`text-2xl font-bold ${c}`}>{v}</p></div>
        ))}
      </div>
      {CashPanel()}
      {lowStock.length > 0 && <div className="bg-red-50 text-red-700 rounded-xl p-3 text-sm">⚠️ Low stock: {lowStock.map(p => `${p.name} (${p.stock})`).join(', ')}</div>}
      <h3 className="font-semibold">Recent orders</h3>
      {orders.length ? orders.slice(0, 3).map(OrderCard) : <p className="text-center text-gray-400 py-8">No orders yet</p>}
    </div>
  )

  const OrdersTab = () => (
    <div className="p-3 space-y-3">
      <h2 className="font-bold text-lg">Orders</h2>
      <p className="text-xs text-gray-400">For privacy you see only the customer's name, never their phone or address. The rider handles delivery.</p>
      {orders.length ? orders.map(OrderCard) : <p className="text-center text-gray-400 py-16">No orders yet</p>}
    </div>
  )

  const Products = () => (
    <div className="p-3 space-y-3">
      <h2 className="font-bold text-lg">New post</h2>
      <div className="bg-white rounded-xl p-3">
        <label className="block border-2 border-dashed rounded-xl h-40 mb-3 overflow-hidden cursor-pointer flex items-center justify-center text-gray-400 text-sm">
          {busy ? 'Processing photo...' : form.img ? <img src={form.img} alt="Preview" className="w-full h-full object-cover" /> : '📸 Tap to add product photo'}
          <input type="file" accept="image/jpeg,image/png,image/webp" onChange={pickPhoto} className="hidden" />
        </label>
        <input className={inp} placeholder="Product name" maxLength={60} value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
        <div className="flex gap-2">
          <input className={inp} type="number" inputMode="numeric" min="1" placeholder="Price ₹" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} />
          <input className={inp} type="number" inputMode="numeric" min="0" placeholder="Stock" value={form.stock} onChange={e => setForm({ ...form, stock: e.target.value })} />
        </div>
        <input className={inp} placeholder="Caption" maxLength={120} value={form.cap} onChange={e => setForm({ ...form, cap: e.target.value })} />
        <p className="text-[11px] text-gray-400 mb-2">Tobacco, alcohol, drugs, weapons and prescription-only medicines are not allowed. Photos are resized and location data is removed.</p>
        <button onClick={addProduct} className="w-full bg-[#0e1f45] text-white font-semibold min-h-12 rounded-xl">Post product</button>
      </div>
      <h3 className="font-semibold">Your products</h3>
      <div className="bg-white rounded-xl p-3">
        {products.map(p => (
          <div key={p.id} className="flex items-center gap-3 py-2 border-b last:border-0">
            <img src={p.img} alt="" className="w-12 h-12 rounded-lg object-cover shrink-0" />
            <div className="flex-1 text-sm min-w-0"><p className="font-semibold truncate">{p.name}</p><p className="text-gray-500">₹{p.price}</p></div>
            <input type="number" inputMode="numeric" value={p.stock} onChange={e => setStock(p.id, e.target.value)} aria-label={`Stock of ${p.name}`}
              className="w-16 border rounded-lg px-2 py-2 text-center" />
            <button aria-label="Delete product" onClick={() => removeProduct(p.id)} className="text-red-500 text-lg w-9 h-9">🗑</button>
          </div>
        ))}
        {!products.length && <p className="text-center text-gray-400 py-6">No products yet</p>}
      </div>
    </div>
  )

  return (
    <>
      {tab === 'dash' && Dash()}
      {tab === 'orders' && OrdersTab()}
      {tab === 'products' && Products()}
      {tab === 'profile' && <Profile db={db} update={update} user={user} shop={shop} logout={logout} showToast={showToast} />}
      <Toast msg={toast} />
      {menu && <ActionSheet title={menu.title} actions={menu.actions} onClose={() => setMenu(null)} />}
      {report && <ReportSheet db={db} update={update} user={user} targets={report.targets} orderId={report.orderId} onClose={() => setReport(null)} showToast={showToast} />}
      <BottomNav tabs={[['dash', 'Dashboard'], ['orders', 'Orders'], ['products', 'Products'], ['profile', 'Me']]} tab={tab} setTab={setTab} badges={{ orders: pending }} />
    </>
  )
}
