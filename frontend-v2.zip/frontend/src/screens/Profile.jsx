import { useState } from 'react'
import ReportSheet from '../components/ReportSheet'
import { DEV_CONTACT } from '../constants'
import { toggleBlock, log } from '../store'

export default function Profile({ db, update, user, shop, logout, showToast }) {
  const [report, setReport] = useState(false)
  const myBlocks = db.blocks.filter(b => b.by === user.id)
  const nameOf = id => {
    const u = db.users.find(x => x.id === id)
    const s = db.shops.find(x => x.owner === id); const p = db.providers.find(x => x.userId === id)
    return s?.name || p?.name || u?.name || 'User'
  }

  const deleteAccount = () => {
    if (user.role !== 'customer') return alert('To delete a shop, rider, doctor or salon account, please contact the developer.')
    if (!confirm('Delete your account and personal details? This cannot be undone.')) return
    update(d => {
      d.users = d.users.filter(u => u.id !== user.id)
      d.orders.forEach(o => { if (o.customer === user.id) { o.phone = ''; o.address = '(removed)'; o.landmark = '' } })
      d.bookings.forEach(b => { if (b.customer === user.id) b.note = '' })
      delete d.follows[user.id]; delete d.liked[user.id]
      d.blocks = d.blocks.filter(b => b.by !== user.id && b.target !== user.id)
      log(d, 'delete', `Customer #${user.id} deleted their account`, user.id)
    })
    logout()
  }

  return (
    <div className="p-3 space-y-3">
      <div className="bg-white rounded-xl p-4 flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-[#0e1f45] text-[#e0b85c] text-2xl font-bold flex items-center justify-center shrink-0">{user.name[0].toUpperCase()}</div>
        <div className="min-w-0">
          <p className="font-bold truncate">{user.name}</p>
          <p className="text-sm text-gray-500">+91 {user.phone}</p>
          <span className="text-xs capitalize bg-gray-100 px-2 py-0.5 rounded-full">{user.role}</span>
          {user.status && user.status !== 'active' && <span className="text-xs bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full ml-1 capitalize">{user.status}</span>}
        </div>
      </div>

      {shop && (
        <div className="bg-white rounded-xl p-4 flex items-center gap-3">
          <img src={shop.logo} alt="" className="w-12 h-12 rounded-full object-cover" />
          <div><p className="font-semibold">{shop.name}</p><p className="text-sm text-gray-500">{shop.cat}</p></div>
        </div>
      )}

      {user.strikes > 0 && <p className="text-sm bg-amber-50 text-amber-800 rounded-xl p-3">You have {user.strikes} strike(s) for missed or failed orders or tokens.</p>}

      <div className="bg-white rounded-xl p-3 space-y-2">
        <p className="font-semibold text-sm">Help & safety</p>
        <button onClick={() => setReport(true)} className="w-full text-left px-4 min-h-12 rounded-xl border">🚩 Report a problem / contact developer</button>
        <a href={`tel:${DEV_CONTACT.phone.replace(/\s/g, '')}`} className="flex items-center px-4 min-h-12 rounded-xl border">📞 Call developer · {DEV_CONTACT.phone}</a>
        <a href={`mailto:${DEV_CONTACT.email}`} className="flex items-center px-4 min-h-12 rounded-xl border wrap-any">✉️ {DEV_CONTACT.email}</a>
      </div>

      {user.role !== 'admin' && (
        <div className="bg-white rounded-xl p-3">
          <p className="font-semibold text-sm mb-2">Blocked ({myBlocks.length})</p>
          {!myBlocks.length && <p className="text-sm text-gray-400">You have not blocked anyone.</p>}
          {myBlocks.map(b => (
            <div key={b.target} className="flex items-center justify-between py-2 border-b last:border-0">
              <span className="text-sm truncate">{nameOf(b.target)}</span>
              <button onClick={() => update(d => { toggleBlock(d, user.id, b.target) })} className="text-sm text-blue-600 px-3 min-h-11">Unblock</button>
            </div>
          ))}
        </div>
      )}

      <button onClick={logout} className="w-full border border-red-300 text-red-600 font-semibold min-h-12 rounded-xl">Log out</button>
      {user.role !== 'admin' && <button onClick={deleteAccount} className="w-full text-xs text-gray-400 underline py-3">Delete my account</button>}
      {report && <ReportSheet db={db} update={update} user={user} targets={[]} onClose={() => setReport(false)} showToast={showToast || (() => {})} />}
    </div>
  )
}
