import { useState } from 'react'
import BottomNav from '../components/BottomNav'
import Sheet from '../components/Sheet'
import ReportSheet from '../components/ReportSheet'
import Profile from './Profile'
import { Toast, useToast } from '../components/Toast'
import { LIMITS } from '../constants'
import { maskPhone, shortName } from '../security'
import { addReport, strike, log } from '../store'

const FAIL_REASONS = [
  ['Customer not reachable', true], ['Customer refused the order', true], ['Wrong or incomplete address', false],
]

export default function Rider({ db, update, user, logout }) {
  const [tab, setTab] = useState('dash')
  const [pins, setPins] = useState({})
  const [failFor, setFailFor] = useState(null)
  const [report, setReport] = useState(null)
  const [toast, showToast] = useToast()

  const shopOf = id => db.shops.find(s => s.id === id)
  const customerOf = id => db.users.find(u => u.id === id)
  const itemsTotal = o => o.total - (o.fee || 0)

  const available = db.orders.filter(o => o.status === 'ready' && !o.rider)
  const active = db.orders.filter(o => o.status === 'picked_up' && o.rider === user.id)
  const done = db.orders.filter(o => o.status === 'delivered' && o.rider === user.id)
  const earnings = done.reduce((t, o) => t + (o.fee || 0), 0)
  const owing = done.filter(o => !o.settled)
  const owedTotal = owing.reduce((t, o) => t + itemsTotal(o), 0)
  const overdue = owing.some(o => (Date.now() - (o.deliveredAt || o.time)) / 36e5 >= LIMITS.cashOverdueHours)

  const pickup = id => {
    if (overdue) return showToast('Hand over your pending cash to the shops first')
    if (active.length >= LIMITS.riderMaxActive) return showToast(`You can carry ${LIMITS.riderMaxActive} orders at a time`)
    update(d => {
      const o = d.orders.find(x => x.id === id)
      if (!o || o.status !== 'ready' || o.rider) return false // someone else was faster
      o.status = 'picked_up'; o.rider = user.id; o.pickedAt = Date.now()
    })
  }

  const deliver = o => {
    if (o.pinLocked) return showToast('Locked. The developer will contact you')
    const entered = (pins[o.id] || '').trim()
    if (!/^\d{4}$/.test(entered)) return showToast("Enter the customer's 4-digit PIN")
    if (entered !== o.pin) {
      update(d => {
        const x = d.orders.find(y => y.id === o.id); if (!x) return false
        x.pinTries = (x.pinTries || 0) + 1
        log(d, 'pin-fail', `Wrong delivery PIN on order #${x.id} (try ${x.pinTries})`, user.id)
        if (x.pinTries >= 3) {
          x.pinLocked = true; x.dispute = true
          addReport(d, { from: user.id, kind: 'rider', target: null, orderId: x.id, reason: 'Wrong delivery PIN 3 times', text: 'Automatic report', system: true })
        }
      })
      return showToast(o.pinTries >= 2 ? 'Too many wrong PINs. Locked.' : 'Wrong PIN. Ask the customer again')
    }
    update(d => {
      const x = d.orders.find(y => y.id === o.id)
      if (!x || x.rider !== user.id || x.status !== 'picked_up') return false
      x.status = 'delivered'; x.deliveredAt = Date.now()
    })
    setPins(p => ({ ...p, [o.id]: '' })); showToast('Delivered. Remember to hand the cash to the shop')
  }

  const failDelivery = (o, reason, giveStrike) => {
    update(d => {
      const x = d.orders.find(y => y.id === o.id)
      if (!x || x.rider !== user.id || x.status !== 'picked_up') return false
      x.status = 'failed'; x.failReason = reason
      x.items.forEach(i => { const p = d.posts.find(z => z.id === i.pid); if (p) p.stock += i.qty }) // goods go back to the shop
      if (giveStrike) strike(d, x.customer, `Order #${x.id}: ${reason}`)
      addReport(d, { from: user.id, kind: 'customer', target: null, orderId: x.id, reason, text: 'Automatic report from a failed delivery', system: true })
    })
    setFailFor(null); showToast('Marked as failed. Return the goods to the shop')
  }

  const Dash = () => (
    <div className="p-3 space-y-3">
      <p className="text-sm text-gray-500">Hi {user.name} 👋</p>
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white rounded-xl p-3"><p className="text-xs text-gray-500">Deliveries</p><p className="text-2xl font-bold">{done.length}</p></div>
        <div className="bg-white rounded-xl p-3"><p className="text-xs text-gray-500">Your earnings</p><p className="text-2xl font-bold text-green-700">₹{earnings}</p></div>
      </div>

      {owing.length > 0 && (
        <div className={`rounded-xl p-3 border-l-4 ${overdue ? 'bg-red-50 border-red-500' : 'bg-white border-amber-400'}`}>
          <p className="font-semibold text-sm">💵 Cash to hand over to shops · ₹{owedTotal}</p>
          <p className="text-xs text-gray-500 mb-1">Give the item money to each shop within {LIMITS.cashOverdueHours} hours. {overdue && <b className="text-red-600">Overdue. You cannot pick up new orders.</b>}</p>
          {owing.map(o => (
            <p key={o.id} className="text-sm flex justify-between py-1 border-t"><span className="truncate">#{o.id} · {shopOf(o.shop)?.name}</span><b>₹{itemsTotal(o)}</b></p>
          ))}
        </div>
      )}

      <h3 className="font-semibold">On the way ({active.length})</h3>
      {active.map(o => {
        const c = customerOf(o.customer)
        return (
          <div key={o.id} className="bg-white rounded-xl p-3 border-l-4 border-green-600">
            <div className="flex justify-between gap-2">
              <b className="truncate">#{o.id} · from {shopOf(o.shop)?.name}</b>
              <button aria-label="Options" className="w-9 h-9 text-lg shrink-0"
                onClick={() => setReport({ orderId: o.id, targets: [{ userId: o.customer, label: shortName(c?.name), kind: 'customer' }] })}>🚩</button>
            </div>
            <p className="text-sm mt-1">{o.items.map(i => `${i.name} × ${i.qty}`).join(', ')}</p>
            <div className="text-sm text-gray-700 mt-2 bg-gray-50 rounded-lg p-2 wrap-any">
              <p>📍 {o.area}, {o.address}</p>
              {o.landmark && <p className="text-xs text-gray-500">Near {o.landmark}</p>}
              <p className="mt-1">👤 {shortName(c?.name)} · {maskPhone(o.phone)} · <a className="text-blue-600 underline" href={`tel:${o.phone}`}>Call</a></p>
            </div>
            <p className="text-sm font-semibold mt-2">💵 Collect ₹{o.total} cash</p>
            <div className="flex gap-2 mt-2">
              <input value={pins[o.id] || ''} onChange={e => setPins({ ...pins, [o.id]: e.target.value.replace(/\D/g, '').slice(0, 4) })}
                inputMode="numeric" maxLength={4} placeholder="PIN" disabled={o.pinLocked} aria-label="Customer delivery PIN"
                className={`w-28 border rounded-xl px-3 text-center min-h-12 disabled:bg-gray-100 ${pins[o.id] ? 'tracking-[0.3em] text-lg' : ''}`} />
              <button onClick={() => deliver(o)} disabled={o.pinLocked} className="flex-1 bg-green-600 disabled:bg-gray-300 text-white min-h-12 rounded-xl text-sm font-semibold">Confirm delivered</button>
            </div>
            {o.pinLocked && <p className="text-xs text-red-600 mt-1">Too many wrong PINs. The developer has been told.</p>}
            <button onClick={() => setFailFor(o)} className="w-full mt-2 text-sm text-red-600 border border-red-200 min-h-11 rounded-xl">Could not deliver</button>
          </div>
        )
      })}
      {!active.length && <p className="text-center text-gray-400 py-4">Nothing in progress</p>}

      <h3 className="font-semibold">Available pickups ({available.length})</h3>
      <p className="text-[11px] text-gray-400 -mt-2">Customer name, phone and full address are shown only after you pick up.</p>
      {available.map(o => (
        <div key={o.id} className="bg-white rounded-xl p-3">
          <div className="flex justify-between gap-2"><b className="truncate">#{o.id} · {shopOf(o.shop)?.name}</b><span className="text-sm text-green-700 font-semibold">₹{o.fee || 0}</span></div>
          <p className="text-sm text-gray-600 mt-1">Drop area: 📍 {o.area} · {o.items.reduce((t, i) => t + i.qty, 0)} item(s)</p>
          <button onClick={() => pickup(o.id)} className="w-full mt-2 bg-[#0e1f45] text-white min-h-11 rounded-lg text-sm font-semibold">Pick up</button>
        </div>
      ))}
      {!available.length && <p className="text-center text-gray-400 py-4">No orders ready right now</p>}
    </div>
  )

  return (
    <>
      {tab === 'dash' && Dash()}
      {tab === 'profile' && <Profile db={db} update={update} user={user} logout={logout} showToast={showToast} />}
      <Toast msg={toast} />
      {failFor && (
        <Sheet title="Why could you not deliver?" onClose={() => setFailFor(null)}>
          <div className="space-y-2">
            {FAIL_REASONS.map(([r, s]) => (
              <button key={r} onClick={() => failDelivery(failFor, r, s)} className="w-full text-left px-4 py-3.5 rounded-xl border">{r}</button>
            ))}
            <p className="text-xs text-gray-500">The goods go back to the shop. The developer is told automatically.</p>
          </div>
        </Sheet>
      )}
      {report && <ReportSheet db={db} update={update} user={user} targets={report.targets} orderId={report.orderId} onClose={() => setReport(null)} showToast={showToast} />}
      <BottomNav tabs={[['dash', 'Deliveries'], ['profile', 'Me']]} tab={tab} setTab={setTab} badges={{ dash: available.length }} />
    </>
  )
}
