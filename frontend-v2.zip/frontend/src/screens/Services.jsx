import { useState, useEffect } from 'react'
import { mosques, PRAYERS, fmt12, nextPrayer, fmtLeft } from '../data/static'
import { ActionSheet } from '../components/Sheet'
import ReportSheet from '../components/ReportSheet'
import { clean, today } from '../security'
import { visibleProviders, isBlockedBetween, toggleBlock } from '../store'
import { LIMITS } from '../constants'

export default function Services({ db, update, user, showToast, initial = 'doctor' }) {
  const [sub, setSub] = useState(initial)
  const [bookingFor, setBookingFor] = useState(null)
  const [note, setNote] = useState('')
  const [mosqueId, setMosqueId] = useState(mosques[0]?.id)
  const [menu, setMenu] = useState(null)
  const [report, setReport] = useState(null)
  const [, tick] = useState(0)

  useEffect(() => {
    const t = setInterval(() => tick(x => x + 1), 30000)
    return () => clearInterval(t)
  }, [])

  const me = db.users.find(u => u.id === user.id)
  const isActive = b => b.status === 'waiting' || b.status === 'serving'
  const providerOf = id => db.providers.find(p => p.id === id)
  const myActive = db.bookings.filter(b => b.customer === user.id && isActive(b))

  const aheadOf = b => {
    const p = providerOf(b.provider)
    const all = db.bookings.filter(x => x.provider === p.id)
    return all.filter(x => x.status === 'waiting' && x.token < b.token).length + (all.some(x => x.status === 'serving') ? 1 : 0)
  }

  const book = p => {
    if (me.status !== 'active') return showToast('Your account is under review')
    if (!p.available) return showToast('Not available right now')
    if (p.userId && isBlockedBetween(db, user.id, p.userId)) return showToast('This provider cannot take your booking')
    // ONE active token in total, so nobody can hoard tokens everywhere
    if (myActive.length) return showToast('You already have an active token. Finish or cancel it first')
    update(d => {
      const pr = d.providers.find(x => x.id === p.id)
      if (!pr || !pr.available) return false
      d.bookings.push({
        id: d.nextBooking++, provider: p.id, customer: user.id, token: pr.nextToken++,
        note: clean(note, 80), status: 'waiting', time: Date.now(), day: today(),
      })
    })
    setBookingFor(null); setNote(''); showToast('Token booked!')
  }

  const cancel = id => update(d => {
    const b = d.bookings.find(x => x.id === id)
    if (!b || b.customer !== user.id || b.status !== 'waiting') return false
    b.status = 'cancelled'
  })

  const MyTokens = () => !myActive.length ? null : (
    <div className="space-y-2">
      <h3 className="font-semibold text-sm">My token</h3>
      {myActive.map(b => {
        const p = providerOf(b.provider); const ahead = aheadOf(b)
        return (
          <div key={b.id} className="bg-white rounded-xl p-3 border-l-4 border-[#e0b85c] flex items-center gap-3">
            <div className="w-14 h-14 rounded-xl bg-[#0e1f45] text-[#e0b85c] flex flex-col items-center justify-center shrink-0">
              <span className="text-[10px]">TOKEN</span><span className="text-xl font-bold leading-none">{b.token}</span>
            </div>
            <div className="flex-1 text-sm min-w-0">
              <p className="font-semibold truncate">{p.name}</p>
              {b.status === 'serving'
                ? <p className="text-green-700 font-semibold">It's your turn now!</p>
                : <p className="text-gray-500">{ahead} ahead · about {ahead * p.avgMin} min</p>}
            </div>
            {b.status === 'waiting' && <button onClick={() => cancel(b.id)} className="text-xs border border-red-300 text-red-600 rounded-lg px-3 min-h-11">Cancel</button>}
          </div>
        )
      })}
      <p className="text-[11px] text-gray-400">Missing your turn without cancelling gives you a strike. {LIMITS.strikesToReview} strikes pause your account.</p>
    </div>
  )

  const List = type => {
    const list = visibleProviders(db, user.id).filter(p => p.type === type)
    return (
      <div className="space-y-3">
        <MyTokens />
        {list.map(p => {
          const waiting = db.bookings.filter(b => b.provider === p.id && b.status === 'waiting').length
          const mine = myActive.some(b => b.provider === p.id)
          return (
            <div key={p.id} className="bg-white rounded-xl p-3">
              <div className="flex justify-between items-start gap-2">
                <div className="min-w-0">
                  <p className="font-bold wrap-any">{p.name}</p>
                  <p className="text-sm text-gray-500 wrap-any">{p.tag}</p>
                  <p className="text-xs text-gray-400 mt-0.5">📍 {p.address} · {type === 'doctor' ? 'Consultation' : 'From'} ₹{p.fee}</p>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <span className={`text-xs font-semibold px-2 py-1 rounded-full whitespace-nowrap ${p.available ? 'bg-green-100 text-green-700' : 'bg-gray-200 text-gray-500'}`}>
                    {p.available ? '● Available' : 'Not available'}
                  </span>
                  {p.userId && (
                    <button aria-label="More options" className="w-9 h-9 text-lg"
                      onClick={() => setMenu({ title: p.name, actions: [
                        { label: '🚩 Report', onClick: () => setReport({ targets: [{ userId: p.userId, label: p.name, kind: 'provider' }] }) },
                        { label: '⛔ Block', danger: true, onClick: () => { if (confirm(`Block ${p.name}?`)) { update(d => { toggleBlock(d, user.id, p.userId) }); showToast('Blocked. Undo it in Profile') } } },
                      ] })}>⋯</button>
                  )}
                </div>
              </div>
              {p.available && (
                <p className="text-sm mt-2 text-gray-700">
                  {p.serving > 0 ? <>Now serving <b>#{p.serving}</b> · </> : null}{waiting} waiting · ~{waiting * p.avgMin} min wait
                </p>
              )}
              {bookingFor === p.id ? (
                <div className="mt-3">
                  <input value={note} onChange={e => setNote(e.target.value)} maxLength={80}
                    placeholder={type === 'doctor' ? 'Reason (optional): fever, checkup...' : 'Service: haircut, beard...'}
                    className="w-full border rounded-xl px-3 py-3 outline-none mb-2" />
                  <div className="flex gap-2">
                    <button onClick={() => book(p)} className="flex-1 bg-green-600 text-white min-h-11 rounded-lg text-sm font-semibold">Confirm token</button>
                    <button onClick={() => setBookingFor(null)} className="px-4 border rounded-lg text-sm min-h-11">Cancel</button>
                  </div>
                </div>
              ) : (
                <div className="flex gap-2 mt-3">
                  {p.phone && p.available && <a href={`tel:${p.phone}`} className="px-4 min-h-11 flex items-center border rounded-lg text-sm">📞 Call</a>}
                  <button disabled={!p.available || mine} onClick={() => setBookingFor(p.id)}
                    className="flex-1 bg-[#0e1f45] disabled:bg-gray-300 text-white min-h-11 rounded-lg text-sm font-semibold">
                    {mine ? 'Token booked' : p.available ? 'Book token' : 'Unavailable'}
                  </button>
                </div>
              )}
            </div>
          )
        })}
        {!list.length && <p className="text-center text-gray-400 py-12">None listed yet</p>}
        <p className="text-[11px] text-gray-400 text-center px-4">Vishram Gram shows who is available. It does not give medical advice. For emergencies go to the nearest hospital.</p>
      </div>
    )
  }

  const Namaz = () => {
    const m = mosques.find(x => x.id === mosqueId) || mosques[0]
    if (!m) return <p className="text-center text-gray-400 py-12">No mosques added yet</p>
    const np = nextPrayer(m.times)
    return (
      <div className="space-y-3">
        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {mosques.map(x => (
            <button key={x.id} onClick={() => setMosqueId(x.id)}
              className={`flex-none px-3 min-h-11 rounded-full text-sm border ${x.id === m.id ? 'bg-[#0e1f45] text-white border-[#0e1f45]' : 'bg-white'}`}>{x.name}</button>
          ))}
        </div>
        <div className="rounded-2xl p-4 text-white" style={{ background: 'linear-gradient(135deg,#0f766e,#14532d)' }}>
          <p className="text-xs opacity-80">Next prayer · {m.area}</p>
          <p className="text-2xl font-bold">{np.label} · {fmt12(np.time)}</p>
          <p className="text-sm opacity-90">in {fmtLeft(np.left)}</p>
        </div>
        <div className="bg-white rounded-xl p-3">
          <p className="text-xs text-gray-500 mb-1">Jamaat times · {m.name}</p>
          {PRAYERS.map(([k, label]) => (
            <div key={k} className={`flex justify-between py-2.5 px-2 rounded-lg ${np.key === k ? 'bg-green-50 font-bold text-green-800' : ''}`}>
              <span>{label}</span><span>{fmt12(m.times[k])}</span>
            </div>
          ))}
          <div className="flex justify-between py-2.5 px-2 border-t mt-1"><span>Jumu'ah (Friday)</span><span className="font-semibold">{fmt12(m.jumuah)}</span></div>
        </div>
        <p className="text-xs text-gray-400 text-center">Times can change through the year. Please confirm with your mosque.</p>
      </div>
    )
  }

  return (
    <div className="p-3 space-y-3">
      <div className="flex bg-white rounded-xl p-1">
        {[['doctor', '🩺 Doctors'], ['salon', '✂️ Salons'], ['namaz', '🕌 Namaz']].map(([id, l]) => (
          <button key={id} onClick={() => setSub(id)}
            className={`flex-1 min-h-11 rounded-lg text-sm font-semibold ${sub === id ? 'bg-[#0e1f45] text-white' : 'text-gray-500'}`}>{l}</button>
        ))}
      </div>
      {sub === 'namaz' ? Namaz() : List(sub)}
      {menu && <ActionSheet title={menu.title} actions={menu.actions} onClose={() => setMenu(null)} />}
      {report && <ReportSheet db={db} update={update} user={user} targets={report.targets} onClose={() => setReport(null)} showToast={showToast} />}
    </div>
  )
}
