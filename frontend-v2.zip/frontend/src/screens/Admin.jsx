import { useState } from 'react'
import BottomNav from '../components/BottomNav'
import { ActionSheet } from '../components/Sheet'
import Profile from './Profile'
import { Toast, useToast } from '../components/Toast'
import { LIMITS, ADMIN_PHONES } from '../constants'
import { clean, validPhone } from '../security'
import { log } from '../store'

const ago = ts => {
  const m = Math.floor((Date.now() - ts) / 60000)
  if (m < 1) return 'just now'
  if (m < 60) return `${m} min ago`
  if (m < 1440) return `${Math.floor(m / 60)} h ago`
  return `${Math.floor(m / 1440)} d ago`
}
const badge = { active: 'bg-green-100 text-green-700', pending: 'bg-blue-100 text-blue-700', review: 'bg-amber-100 text-amber-800', blocked: 'bg-red-100 text-red-700' }
const hexOk = v => /^#[0-9a-fA-F]{6}$/.test(v)
const inp = 'w-full border rounded-xl px-3 py-3 outline-none mb-2'

export default function Admin({ db, update, user, logout }) {
  const [tab, setTab] = useState('dash')
  const [q, setQ] = useState('')
  const [menu, setMenu] = useState(null)
  const [num, setNum] = useState('')
  const [numWhy, setNumWhy] = useState('')
  const [toast, showToast] = useToast()
  const [adEdit, setAdEdit] = useState(null)

  const users = db.users.filter(u => u.role !== 'admin')
  const userOf = id => db.users.find(u => u.id === id)
  const labelOf = u => {
    if (!u) return 'System'
    const s = db.shops.find(x => x.owner === u.id); const p = db.providers.find(x => x.userId === u.id)
    return `${u.name}${s ? ` (${s.name})` : p ? ` (${p.name})` : ''}`
  }
  const pendingUsers = users.filter(u => u.status === 'pending')
  const openReports = db.reports.filter(r => r.status === 'open')
  const itemsTotal = o => o.total - (o.fee || 0)

  // ---------- actions (every one is written to the audit log) ----------
  const approve = u => update(d => { d.users.find(x => x.id === u.id).status = 'active'; log(d, 'approve', `Approved ${u.name} (${u.role})`, user.id) })

  const reject = u => {
    if (!confirm(`Reject and remove ${u.name}?`)) return
    update(d => {
      d.shops = d.shops.filter(s => !(s.owner === u.id && s.id >= 100))
      d.shops.forEach(s => { if (s.owner === u.id) s.owner = null })
      d.providers = d.providers.filter(p => !(p.userId === u.id && p.id >= 100))
      d.providers.forEach(p => { if (p.userId === u.id) p.userId = null })
      d.users = d.users.filter(x => x.id !== u.id)
      log(d, 'reject', `Rejected ${u.name} (${u.role})`, user.id)
    })
  }

  const blockUser = (u, reason) => update(d => {
    const x = d.users.find(y => y.id === u.id); if (!x || x.role === 'admin' || ADMIN_PHONES.includes(x.phone)) return false
    x.status = 'blocked'; x.statusReason = reason
    if (!d.blockedPhones.some(b => b.phone === x.phone)) d.blockedPhones.push({ phone: x.phone, reason, ts: Date.now() })
    if (x.deviceId && !d.blockedDevices.includes(x.deviceId)) d.blockedDevices.push(x.deviceId)
    log(d, 'block', `Blocked ${x.name} (${x.phone}): ${reason}`, user.id)
  })

  const unblockUser = u => update(d => {
    const x = d.users.find(y => y.id === u.id); if (!x) return false
    x.status = 'active'; x.statusReason = ''; x.strikes = 0
    d.blockedPhones = d.blockedPhones.filter(b => b.phone !== x.phone)
    d.blockedDevices = d.blockedDevices.filter(v => v !== x.deviceId)
    log(d, 'unblock', `Reinstated ${x.name}`, user.id)
  })

  const blockNumber = () => {
    if (!validPhone(num)) return showToast('Enter a valid 10-digit number')
    if (ADMIN_PHONES.includes(num)) return showToast('You cannot block the developer number')
    const why = clean(numWhy, 80) || 'Blocked by developer'
    update(d => {
      if (!d.blockedPhones.some(b => b.phone === num)) d.blockedPhones.push({ phone: num, reason: why, ts: Date.now() })
      const x = d.users.find(u => u.phone === num && u.role !== 'admin')
      if (x) { x.status = 'blocked'; x.statusReason = why; if (x.deviceId && !d.blockedDevices.includes(x.deviceId)) d.blockedDevices.push(x.deviceId) }
      log(d, 'block-number', `Blocked number ${num}: ${why}`, user.id)
    })
    setNum(''); setNumWhy(''); showToast('Number blocked')
  }

  const setReport = (id, status) => update(d => { const r = d.reports.find(x => x.id === id); r.status = status; log(d, 'report-' + status, `Report #${id} ${status}`, user.id) })
  const unlockPin = orderId => update(d => {
    const o = d.orders.find(x => x.id === orderId); if (!o) return false
    o.pinLocked = false; o.pinTries = 0; o.dispute = false; log(d, 'pin-unlock', `Unlocked PIN of order #${orderId}`, user.id)
  })

  const userMenu = u => setMenu({ title: `${u.name} · ${u.phone}`, actions: [
    u.status === 'pending' && { label: '✅ Approve', onClick: () => approve(u) },
    (u.status === 'review') && { label: '✅ Reinstate (clear review)', onClick: () => unblockUser(u) },
    u.status !== 'blocked' && { label: '⛔ Block this user and number', danger: true, onClick: () => { const r = prompt('Reason for blocking?'); if (r) blockUser(u, clean(r, 80)) } },
    u.status === 'blocked' && { label: '♻️ Unblock', onClick: () => unblockUser(u) },
    u.strikes > 0 && { label: 'Reset strikes', onClick: () => update(d => { d.users.find(x => x.id === u.id).strikes = 0 }) },
  ] })

  // ---------- views ----------
  const Dash = () => {
    const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0)
    const todayOrders = db.orders.filter(o => o.time >= dayStart.getTime())
    const owing = {}
    db.orders.filter(o => o.status === 'delivered' && !o.settled && o.rider).forEach(o => {
      const r = (owing[o.rider] ||= { sum: 0, oldest: Date.now() })
      r.sum += itemsTotal(o); r.oldest = Math.min(r.oldest, o.deliveredAt || o.time)
    })
    const stat = (l, v, c = '') => <div className="bg-white rounded-xl p-3"><p className="text-xs text-gray-500">{l}</p><p className={`text-2xl font-bold ${c}`}>{v}</p></div>
    return (
      <div className="p-3 space-y-3">
        <p className="font-bold text-lg">Developer dashboard</p>
        <div className="grid grid-cols-2 gap-3">
          {stat('Waiting for approval', pendingUsers.length, pendingUsers.length ? 'text-blue-600' : '')}
          {stat('Open reports', openReports.length, openReports.length ? 'text-red-600' : '')}
          {stat('Under review', users.filter(u => u.status === 'review').length, 'text-amber-600')}
          {stat('Blocked', users.filter(u => u.status === 'blocked').length)}
          {stat('Orders today', todayOrders.length)}
          {stat('Users', users.length)}
        </div>
        <div className="bg-white rounded-xl p-3">
          <p className="font-semibold text-sm mb-1">💵 Cash riders still owe shops</p>
          {!Object.keys(owing).length && <p className="text-sm text-gray-400">All settled</p>}
          {Object.entries(owing).map(([rid, v]) => {
            const hrs = Math.floor((Date.now() - v.oldest) / 36e5); const late = hrs >= LIMITS.cashOverdueHours
            return (
              <div key={rid} className="flex justify-between py-2 border-t text-sm">
                <span className="truncate">{userOf(+rid)?.name || 'Rider'}</span>
                <span className={late ? 'text-red-600 font-semibold' : ''}>₹{v.sum} · oldest {hrs}h{late ? ' · OVERDUE' : ''}</span>
              </div>
            )
          })}
        </div>
        <p className="text-[11px] text-gray-400">Demo note: this data lives in this browser only. With the backend, every phone will feed this dashboard live.</p>
      </div>
    )
  }

  const Approvals = () => (
    <div className="p-3 space-y-3">
      <h2 className="font-bold text-lg">Approvals ({pendingUsers.length})</h2>
      <p className="text-xs text-gray-500">Check each one in person or by phone before approving: shop licence/visit, doctor's medical council registration, rider ID.</p>
      {!pendingUsers.length && <p className="text-center text-gray-400 py-12">Nobody is waiting</p>}
      {pendingUsers.map(u => {
        const s = db.shops.find(x => x.owner === u.id); const p = db.providers.find(x => x.userId === u.id)
        return (
          <div key={u.id} className="bg-white rounded-xl p-3">
            <div className="flex justify-between gap-2"><b className="truncate">{u.name}</b><span className="text-xs capitalize bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">{u.role}</span></div>
            <p className="text-sm text-gray-600">📞 {u.phone} · joined {ago(u.createdAt || Date.now())}</p>
            {s && <p className="text-sm">🏪 {s.name} ({s.cat})</p>}
            {p && <p className="text-sm">{p.type === 'doctor' ? '🩺' : '✂️'} {p.name} · {p.tag} · ₹{p.fee}</p>}
            <div className="flex gap-2 mt-3">
              <button onClick={() => approve(u)} className="flex-1 bg-green-600 text-white min-h-11 rounded-lg text-sm font-semibold">Approve</button>
              <button onClick={() => reject(u)} className="flex-1 bg-red-500 text-white min-h-11 rounded-lg text-sm font-semibold">Reject</button>
            </div>
          </div>
        )
      })}
    </div>
  )

  const Reports = () => {
    const list = [...openReports, ...db.reports.filter(r => r.status !== 'open').slice(0, 15)]
    return (
      <div className="p-3 space-y-3">
        <h2 className="font-bold text-lg">Reports ({openReports.length} open)</h2>
        {!list.length && <p className="text-center text-gray-400 py-12">No reports</p>}
        {list.map(r => {
          const from = userOf(r.from); const tgt = userOf(r.target); const o = r.orderId ? db.orders.find(x => x.id === r.orderId) : null
          const others = r.target ? db.reports.filter(x => x.target === r.target && x.id !== r.id).length : 0
          return (
            <div key={r.id} className={`bg-white rounded-xl p-3 ${r.status === 'open' ? 'border-l-4 border-red-400' : 'opacity-70'}`}>
              <div className="flex justify-between gap-2">
                <b className="text-sm">#{r.id} · {r.reason}</b>
                <span className="text-[11px] text-gray-400 shrink-0">{ago(r.ts)}</span>
              </div>
              <p className="text-xs text-gray-600 mt-1 wrap-any">From: {labelOf(from) || 'System'}{from ? ` · ${from.phone}` : ''}</p>
              <p className="text-xs text-gray-600 wrap-any">About: {tgt ? `${labelOf(tgt)} · ${tgt.phone} · ${tgt.status}` : (r.system ? 'Automatic report' : 'Developer / app')}{others ? ` · ${others} other report(s)` : ''}</p>
              {o && <p className="text-xs text-gray-600">Order #{o.id} · {o.status}{o.dispute ? ' · DISPUTE' : ''} · ₹{o.total}</p>}
              {r.text && <p className="text-sm mt-2 bg-gray-50 rounded-lg p-2 wrap-any">“{r.text}”</p>}
              {r.status === 'open' ? (
                <div className="flex flex-wrap gap-2 mt-3">
                  {tgt && tgt.status !== 'blocked' && <button onClick={() => { if (confirm(`Block ${tgt.name} and their number?`)) { blockUser(tgt, `Report #${r.id}: ${r.reason}`); setReport(r.id, 'resolved') } }} className="flex-1 min-w-[120px] bg-red-500 text-white min-h-11 rounded-lg text-sm">Block user</button>}
                  {o && o.pinLocked && <button onClick={() => { unlockPin(o.id); setReport(r.id, 'resolved') }} className="flex-1 min-w-[120px] border min-h-11 rounded-lg text-sm">Unlock PIN</button>}
                  <button onClick={() => setReport(r.id, 'resolved')} className="flex-1 min-w-[100px] bg-green-600 text-white min-h-11 rounded-lg text-sm">Resolved</button>
                  <button onClick={() => setReport(r.id, 'dismissed')} className="flex-1 min-w-[100px] border min-h-11 rounded-lg text-sm">Dismiss</button>
                </div>
              ) : <p className="text-xs text-gray-400 mt-2 capitalize">{r.status}</p>}
            </div>
          )
        })}
      </div>
    )
  }

  const Users = () => {
    const t = clean(q, 30).toLowerCase()
    const list = users.filter(u => !t || (u.name + u.phone + u.role + u.status).toLowerCase().includes(t))
    return (
      <div className="p-3 space-y-3">
        <h2 className="font-bold text-lg">Users ({users.length})</h2>
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search name, phone, role, status" className="w-full bg-white rounded-xl px-4 py-3 outline-none" />
        {list.map(u => (
          <button key={u.id} onClick={() => userMenu(u)} className="w-full text-left bg-white rounded-xl p-3 flex items-center justify-between gap-2">
            <span className="min-w-0"><b className="block truncate">{labelOf(u)}</b><span className="text-xs text-gray-500 capitalize">{u.role} · {u.phone}{u.strikes ? ` · ${u.strikes} strike(s)` : ''}</span></span>
            <span className={`text-xs px-2 py-0.5 rounded-full capitalize shrink-0 ${badge[u.status] || ''}`}>{u.status}</span>
          </button>
        ))}
        {!list.length && <p className="text-center text-gray-400 py-10">No users</p>}
      </div>
    )
  }

  const saveAd = a => {
    const title = clean(a.title, 50), text = clean(a.text, 120), cta = clean(a.cta, 20)
    if (title.length < 2) return showToast('Enter a title')
    if (!hexOk(a.c1) || !hexOk(a.c2)) return showToast('Pick two colours')
    update(d => {
      if (a.id) Object.assign(d.ads.find(x => x.id === a.id), { title, text, cta, c1: a.c1, c2: a.c2, active: a.active })
      else d.ads.push({ id: d.nextAd++, title, text, cta, c1: a.c1, c2: a.c2, active: a.active })
      log(d, 'ad', `Ad saved: ${title}`, user.id)
    })
    setAdEdit(null); showToast('Ad saved')
  }

  const More = () => (
    <div className="p-3 space-y-4">
      <div className="bg-white rounded-xl p-3">
        <p className="font-semibold mb-2">⛔ Block a suspicious number</p>
        <input value={num} onChange={e => setNum(e.target.value.replace(/\D/g, ''))} inputMode="numeric" maxLength={10} placeholder="10-digit mobile number" className={inp} />
        <input value={numWhy} onChange={e => setNumWhy(e.target.value)} maxLength={80} placeholder="Reason" className={inp} />
        <button onClick={blockNumber} className="w-full bg-red-500 text-white min-h-12 rounded-xl font-semibold">Block number</button>
        <p className="text-xs text-gray-500 mt-3 mb-1">Blocked numbers ({db.blockedPhones.length})</p>
        {db.blockedPhones.map(b => (
          <div key={b.phone} className="flex items-center justify-between py-1.5 border-t text-sm gap-2">
            <span className="min-w-0 truncate">{b.phone} <span className="text-gray-400">· {b.reason}</span></span>
            <button className="text-blue-600 px-2 min-h-11 shrink-0" onClick={() => update(d => { d.blockedPhones = d.blockedPhones.filter(x => x.phone !== b.phone); log(d, 'unblock-number', `Unblocked ${b.phone}`, user.id) })}>Unblock</button>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl p-3">
        <div className="flex items-center justify-between mb-2">
          <p className="font-semibold">📢 Ads ({db.ads.length})</p>
          {db.ads.length < 8 && <button onClick={() => setAdEdit({ title: '', text: '', cta: '', c1: '#0e1f45', c2: '#2b4a9a', active: true })} className="text-sm bg-[#0e1f45] text-white px-3 min-h-11 rounded-lg">+ New ad</button>}
        </div>
        {db.ads.map(a => (
          <div key={a.id} className="rounded-xl p-3 text-white mb-2" style={{ background: `linear-gradient(135deg, ${a.c1}, ${a.c2})`, opacity: a.active ? 1 : 0.45 }}>
            <p className="font-bold wrap-any">{a.title}</p><p className="text-sm opacity-90 wrap-any">{a.text}</p>
            <div className="flex gap-2 mt-2">
              <button onClick={() => setAdEdit({ ...a })} className="text-xs bg-white/90 text-slate-900 px-3 min-h-9 rounded-full">Edit</button>
              <button onClick={() => update(d => { const x = d.ads.find(y => y.id === a.id); x.active = !x.active })} className="text-xs bg-white/90 text-slate-900 px-3 min-h-9 rounded-full">{a.active ? 'Hide' : 'Show'}</button>
              <button onClick={() => { if (confirm('Delete this ad?')) update(d => { d.ads = d.ads.filter(y => y.id !== a.id) }) }} className="text-xs bg-white/90 text-red-600 px-3 min-h-9 rounded-full">Delete</button>
            </div>
          </div>
        ))}
        {adEdit && (
          <div className="border rounded-xl p-3 mt-2">
            <input className={inp} placeholder="Title" maxLength={50} value={adEdit.title} onChange={e => setAdEdit({ ...adEdit, title: e.target.value })} />
            <input className={inp} placeholder="Text" maxLength={120} value={adEdit.text} onChange={e => setAdEdit({ ...adEdit, text: e.target.value })} />
            <input className={inp} placeholder="Button text (optional)" maxLength={20} value={adEdit.cta} onChange={e => setAdEdit({ ...adEdit, cta: e.target.value })} />
            <div className="flex gap-3 items-center mb-2 text-sm">Colours <input type="color" aria-label="Colour 1" value={adEdit.c1} onChange={e => setAdEdit({ ...adEdit, c1: e.target.value })} className="w-12 h-10" />
              <input type="color" aria-label="Colour 2" value={adEdit.c2} onChange={e => setAdEdit({ ...adEdit, c2: e.target.value })} className="w-12 h-10" /></div>
            <div className="flex gap-2"><button onClick={() => saveAd(adEdit)} className="flex-1 bg-green-600 text-white min-h-11 rounded-lg">Save</button>
              <button onClick={() => setAdEdit(null)} className="px-4 border rounded-lg min-h-11">Cancel</button></div>
          </div>
        )}
        <p className="text-[11px] text-gray-400 mt-2">Ads show as plain text only. Nothing from an ad is ever run as code.</p>
      </div>

      <div className="bg-white rounded-xl p-3">
        <p className="font-semibold mb-2">🧾 Activity log</p>
        {db.audit.slice(0, 40).map((a, i) => (
          <p key={i} className="text-xs py-1.5 border-t wrap-any"><span className="text-gray-400">{ago(a.ts)}</span> · <b>{a.type}</b> · {a.text}</p>
        ))}
        {!db.audit.length && <p className="text-sm text-gray-400">Nothing yet</p>}
      </div>
    </div>
  )

  return (
    <>
      {tab === 'dash' && Dash()}
      {tab === 'appr' && Approvals()}
      {tab === 'reports' && Reports()}
      {tab === 'users' && Users()}
      {tab === 'more' && More()}
      {tab === 'me' && <Profile db={db} update={update} user={user} logout={logout} showToast={showToast} />}
      <Toast msg={toast} />
      {menu && <ActionSheet title={menu.title} actions={menu.actions} onClose={() => setMenu(null)} />}
      <BottomNav
        tabs={[['dash', 'Overview', 'dash'], ['appr', 'Approve', 'check'], ['reports', 'Reports', 'flag'], ['users', 'Users', 'users'], ['more', 'More', 'more'], ['me', 'Me', 'profile']]}
        tab={tab} setTab={setTab} badges={{ appr: pendingUsers.length, reports: openReports.length }} />
    </>
  )
}
