import { useState, useEffect } from 'react'
import { ADMIN_PHONES, ADMIN_PASS_HASH, DEV_CONTACT } from '../constants'
import { clean, validName, validPhone, toInt, sha256, otpCanSend, otpMarkSent, otpFail, otpClear } from '../security'
import { log } from '../store'

const DEMO_OTP = '1234'
const inp = 'w-full border rounded-xl px-4 py-3 outline-none focus:border-[#0e1f45] mb-3'
const ROLES = [['customer', '🛍 Customer'], ['shopkeeper', '🏪 Shop'], ['rider', '🛵 Rider'], ['doctor', '🩺 Doctor'], ['salon', '✂️ Salon']]

export default function Auth({ db, update, login, device }) {
  const [mode, setMode] = useState('login') // login | signup | admin
  const [phone, setPhone] = useState('')
  const [pass, setPass] = useState('')
  const [otp, setOtp] = useState('')
  const [sent, setSent] = useState(false)
  const [name, setName] = useState('')
  const [role, setRole] = useState('customer')
  const [agree, setAgree] = useState(false)
  const [shopChoice, setShopChoice] = useState('new')
  const [shopName, setShopName] = useState('')
  const [shopCat, setShopCat] = useState('')
  const [provChoice, setProvChoice] = useState('new')
  const [provName, setProvName] = useState('')
  const [provTag, setProvTag] = useState('')
  const [provFee, setProvFee] = useState('')
  const [provAddr, setProvAddr] = useState('')
  const [err, setErr] = useState('')
  const [wait, setWait] = useState(0)

  useEffect(() => {
    if (wait <= 0) return
    const t = setTimeout(() => setWait(w => w - 1), 1000)
    return () => clearTimeout(t)
  }, [wait])

  const isProv = role === 'doctor' || role === 'salon'
  const unowned = db.shops.filter(s => !s.owner)
  const unownedProv = db.providers.filter(p => !p.userId && p.type === role)
  const existing = db.users.find(u => u.phone === phone)

  const switchMode = m => { setMode(m); setSent(false); setErr(''); setOtp(''); setPass('') }
  const pickRole = r => { setRole(r); setShopChoice('new'); setProvChoice('new') }

  const refuse = (why, msg) => { update(d => { log(d, 'blocked-attempt', `${why} (${phone || 'no phone'})`) }); setErr(msg) }
  const BLOCKED_MSG = `This number or phone cannot be used on Vishram Gram. If this is a mistake, contact the developer on ${DEV_CONTACT.phone}.`

  const sendOtp = () => {
    setErr('')
    if (!validPhone(phone)) return setErr('Enter a valid 10-digit mobile number')
    // the developer's own number can never be blocked, so you cannot lock yourself out
    if (!ADMIN_PHONES.includes(phone) && (db.blockedPhones.some(b => b.phone === phone) || db.blockedDevices.includes(device))) return refuse('Blocked phone or device tried to continue', BLOCKED_MSG)

    if (mode === 'admin') {
      const lock = otpCanSend(phone)
      if (!lock.ok && lock.why === 'locked') return setErr(`Too many wrong attempts. Try again in ${Math.ceil(lock.wait / 60)} min`)
      if (!ADMIN_PHONES.includes(phone) || sha256(pass) !== ADMIN_PASS_HASH) {
        const f = otpFail(phone)
        update(d => { log(d, 'admin-fail', `Wrong admin login for ${phone}`) })
        return setErr(f.locked ? `Locked for a few minutes after too many wrong attempts.` : `Wrong phone or passcode. ${f.left} attempts left.`)
      }
    }

    if (mode === 'login') {
      if (!existing) return setErr('No account found. Please sign up first.')
      if (existing.status === 'blocked') return refuse('Blocked user tried to log in', `This account has been blocked. Contact the developer on ${DEV_CONTACT.phone}.`)
    }
    if (mode === 'signup') {
      if (existing) return setErr('This number is already registered. Please log in.')
      const n = clean(name, 40)
      if (!validName(n)) return setErr('Enter your real name (letters only, 2 to 40 characters)')
      if (!agree) return setErr('Please accept the rules to continue')
      if (role === 'shopkeeper' && shopChoice === 'new' && (clean(shopName, 40).length < 2 || clean(shopCat, 30).length < 2))
        return setErr('Enter your shop name and category')
      if (isProv && provChoice === 'new') {
        if (clean(provName, 50).length < 2) return setErr(role === 'doctor' ? 'Enter your clinic name' : 'Enter your salon name')
        if (provFee !== '' && toInt(provFee, 0, 10000) === null) return setErr('Fee must be between 0 and 10000')
      }
    }

    const can = otpCanSend(phone)
    if (!can.ok) {
      if (can.why === 'locked') return setErr(`Too many wrong OTPs. Try again in ${Math.ceil(can.wait / 60)} min`)
      if (can.why === 'cooldown') { setSent(true); setWait(can.wait); return }
      return setErr(`Too many OTP requests. Try again in ${Math.ceil(can.wait / 60)} min`)
    }
    otpMarkSent(phone); setWait(30); setSent(true)
  }

  const verify = () => {
    setErr('')
    if (otp.length !== 4) return setErr('Enter the 4-digit OTP')
    if (otp !== DEMO_OTP) {
      const f = otpFail(phone)
      update(d => { log(d, 'otp-fail', `Wrong OTP for ${phone}`) })
      if (f.locked) { setSent(false); setOtp(''); return setErr(`Too many wrong OTPs. Locked for a few minutes.`) }
      return setErr(`Wrong OTP. ${f.left} attempts left. (Demo OTP is 1234)`)
    }
    otpClear(phone)

    if (mode === 'login') { update(d => { log(d, 'login', `${existing.name} logged in`, existing.id) }); return login(existing.id) }

    if (mode === 'admin') {
      let id = db.users.find(u => u.phone === phone && u.role === 'admin')?.id
      if (!id) {
        id = db.nextUser
        update(d => { d.users.push({ id, name: 'Developer', phone, role: 'admin', status: 'active', strikes: 0, createdAt: Date.now() }); d.nextUser++ })
      }
      update(d => { log(d, 'admin-login', 'Admin logged in', id) })
      return login(id)
    }

    // ----- sign up -----
    const id = db.nextUser
    const nm = clean(name, 40)
    update(d => {
      if (d.users.some(u => u.phone === phone)) return false // double-tap safety
      let shopId = null, providerId = null
      if (role === 'shopkeeper') {
        if (shopChoice === 'new') {
          shopId = d.nextShop++
          d.shops.push({
            id: shopId, name: clean(shopName, 40), cat: clean(shopCat, 30), bio: 'New on Vishram Gram',
            logo: `https://picsum.photos/seed/shop${shopId}/200/200`, followers: 0, owner: id,
          })
        } else {
          shopId = Number(shopChoice)
          const s = d.shops.find(x => x.id === shopId)
          if (!s || s.owner) return false
          s.owner = id
        }
      }
      if (isProv) {
        if (provChoice === 'new') {
          providerId = d.nextProvider++
          d.providers.push({
            id: providerId, userId: id, type: role, name: clean(provName, 50), tag: clean(provTag, 60),
            fee: toInt(provFee, 0, 10000) || 0, address: clean(provAddr, 80), phone,
            avgMin: role === 'doctor' ? 10 : 20, available: false, serving: 0, nextToken: 1, day: new Date().toLocaleDateString('en-CA'),
          })
        } else {
          providerId = Number(provChoice)
          const p = d.providers.find(x => x.id === providerId)
          if (!p || p.userId) return false
          p.userId = id; p.phone = phone
        }
      }
      d.users.push({
        id, name: nm, phone, role, shopId, providerId, strikes: 0, createdAt: Date.now(), deviceId: device,
        status: role === 'customer' ? 'active' : 'pending',
      })
      d.nextUser++
      log(d, 'signup', `${nm} signed up as ${role}`, id)
    })
    login(id)
  }

  return (
    <div className="p-5">
      <div className="text-center mt-2 mb-5">
        <img src="/logo-icon.svg" alt="" className="w-20 h-20 mx-auto" />
        <h2 className="text-xl font-extrabold text-[#0e1f45] mt-2">Welcome to Vishram Gram</h2>
        <p className="text-sm text-gray-500">Shop from Melvisharam, delivered in minutes</p>
      </div>

      <div className="bg-white rounded-2xl shadow p-5">
        {mode !== 'admin' ? (
          <div className="flex mb-4 bg-gray-100 rounded-xl p-1">
            {[['login', 'Log in'], ['signup', 'Sign up']].map(([m, l]) => (
              <button key={m} onClick={() => switchMode(m)}
                className={`flex-1 py-2.5 rounded-lg text-sm font-semibold ${mode === m ? 'bg-white shadow text-[#0e1f45]' : 'text-gray-500'}`}>{l}</button>
            ))}
          </div>
        ) : (
          <div className="mb-4 flex items-center justify-between">
            <p className="font-bold">🔐 Developer login</p>
            <button onClick={() => switchMode('login')} className="text-sm text-gray-500 underline">Back</button>
          </div>
        )}

        {!sent ? (
          <>
            {mode === 'signup' && (
              <>
                <input className={inp} placeholder="Your full name" value={name} maxLength={40} autoComplete="name" onChange={e => setName(e.target.value)} />
                <p className="text-xs text-gray-500 mb-1">I am a</p>
                <div className="grid grid-cols-3 gap-2 mb-3">
                  {ROLES.map(([r, l]) => (
                    <button key={r} onClick={() => pickRole(r)}
                      className={`min-h-11 py-2 rounded-xl text-xs border ${role === r ? 'bg-[#0e1f45] text-white border-[#0e1f45]' : 'bg-white'}`}>{l}</button>
                  ))}
                </div>
                {role !== 'customer' && (
                  <p className="text-xs bg-blue-50 text-blue-800 rounded-lg p-2 mb-3">
                    ✅ Shops, riders, doctors and salons are checked by the developer before going live. You can sign up now and you will be approved after verification.
                  </p>
                )}

                {role === 'shopkeeper' && (
                  <>
                    <select className={inp} value={shopChoice} onChange={e => setShopChoice(e.target.value)}>
                      <option value="new">➕ Register a new shop</option>
                      {unowned.map(s => <option key={s.id} value={s.id}>{s.name} ({s.cat})</option>)}
                    </select>
                    {shopChoice === 'new' && (
                      <>
                        <input className={inp} placeholder="Shop name" value={shopName} maxLength={40} onChange={e => setShopName(e.target.value)} />
                        <input className={inp} placeholder="Category, e.g. Grocery" value={shopCat} maxLength={30} onChange={e => setShopCat(e.target.value)} />
                      </>
                    )}
                  </>
                )}

                {isProv && (
                  <>
                    <select className={inp} value={provChoice} onChange={e => setProvChoice(e.target.value)}>
                      <option value="new">➕ Register a new {role === 'doctor' ? 'clinic' : 'salon'}</option>
                      {unownedProv.map(p => <option key={p.id} value={p.id}>{p.name} (sample)</option>)}
                    </select>
                    {provChoice === 'new' && (
                      <>
                        <input className={inp} placeholder={role === 'doctor' ? 'Clinic / doctor name' : 'Salon name'} value={provName} maxLength={50} onChange={e => setProvName(e.target.value)} />
                        <input className={inp} placeholder={role === 'doctor' ? 'Speciality (General, Child...)' : 'Services (Haircut, Beard...)'} value={provTag} maxLength={60} onChange={e => setProvTag(e.target.value)} />
                        <input className={inp} type="number" inputMode="numeric" placeholder={role === 'doctor' ? 'Consultation fee ₹' : 'Starting price ₹'} value={provFee} onChange={e => setProvFee(e.target.value)} />
                        <input className={inp} placeholder="Address / area" value={provAddr} maxLength={80} onChange={e => setProvAddr(e.target.value)} />
                      </>
                    )}
                  </>
                )}
              </>
            )}

            <div className="flex items-center border rounded-xl px-4 mb-3 focus-within:border-[#0e1f45]">
              <span className="text-gray-500 mr-2">+91</span>
              <input className="flex-1 py-3 outline-none min-w-0" inputMode="numeric" autoComplete="tel-national" maxLength={10}
                placeholder="Mobile number" value={phone} onChange={e => setPhone(e.target.value.replace(/\D/g, ''))} />
            </div>

            {mode === 'admin' && (
              <input className={inp} type="password" autoComplete="current-password" placeholder="Admin passcode" value={pass} onChange={e => setPass(e.target.value)} />
            )}

            {mode === 'signup' && (
              <label className="flex items-start gap-2 text-xs text-gray-600 mb-3">
                <input type="checkbox" checked={agree} onChange={e => setAgree(e.target.checked)} className="mt-0.5 w-5 h-5 shrink-0" />
                <span>I will not place fake orders, share false information or sell banned items (tobacco, alcohol, drugs, weapons). I understand my account can be blocked for misuse.</span>
              </label>
            )}

            <button onClick={sendOtp} className="w-full bg-[#0e1f45] text-white font-semibold py-3.5 rounded-xl">Send OTP</button>
          </>
        ) : (
          <>
            <p className="text-sm text-gray-600 mb-2">OTP sent to +91 {phone}</p>
            <p className="text-xs bg-yellow-50 text-yellow-700 rounded-lg p-2 mb-3">Demo mode: the OTP is <b>1234</b>. Real SMS comes with the backend.</p>
            <input className={`${inp} text-center tracking-[0.5em] text-lg`} inputMode="numeric" autoComplete="one-time-code" maxLength={4}
              placeholder="----" value={otp} onChange={e => setOtp(e.target.value.replace(/\D/g, ''))} />
            <button onClick={verify} className="w-full bg-green-600 text-white font-semibold py-3.5 rounded-xl">
              Verify & {mode === 'signup' ? 'Create account' : 'Log in'}
            </button>
            <div className="flex justify-between mt-3 text-sm">
              <button onClick={() => { setSent(false); setOtp(''); setErr('') }} className="text-gray-500 py-2">Change number</button>
              <button onClick={sendOtp} disabled={wait > 0} className="text-blue-600 disabled:text-gray-400 py-2">
                {wait > 0 ? `Resend in ${wait}s` : 'Resend OTP'}
              </button>
            </div>
          </>
        )}
        {err && <p role="alert" className="text-sm text-red-600 mt-3 wrap-any">{err}</p>}
      </div>

      <div className="flex justify-center gap-5 mt-6 text-xs text-gray-400">
        {mode !== 'admin' && <button onClick={() => switchMode('admin')} className="underline py-2">Developer login</button>}
        <button onClick={() => { if (confirm('Delete ALL demo data on this phone?')) { localStorage.clear(); location.reload() } }} className="underline py-2">Reset demo data</button>
      </div>
    </div>
  )
}
