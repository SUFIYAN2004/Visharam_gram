import { useState } from 'react'
import BottomNav from '../components/BottomNav'
import { ActionSheet } from '../components/Sheet'
import ReportSheet from '../components/ReportSheet'
import Profile from './Profile'
import { Toast, useToast } from '../components/Toast'
import { toInt, shortName, maskPhone } from '../security'
import { toggleBlock, strike } from '../store'

export default function Provider({ db, update, user, logout }) {
  const [tab, setTab] = useState('dash')
  const [menu, setMenu] = useState(null)
  const [report, setReport] = useState(null)
  const [toast, showToast] = useToast()

  const p = db.providers.find(x => x.id === user.providerId)
  const mine = db.bookings.filter(b => b.provider === p.id)
  const queue = mine.filter(b => b.status === 'waiting' || b.status === 'serving').sort((a, b) => a.token - b.token)
  const waiting = queue.filter(b => b.status === 'waiting').length
  const done = mine.filter(b => b.status === 'done').length
  const custOf = id => db.users.find(u => u.id === id)
  const isDoctor = p.type === 'doctor'

  const patch = fn => update(d => fn(d.providers.find(x => x.id === p.id), d.bookings.filter(b => b.provider === p.id), d))

  const toggle = () => patch(pr => { pr.available = !pr.available })

  const callNext = () => patch((pr, bk) => {
    bk.forEach(b => { if (b.status === 'serving') b.status = 'done' })
    const next = bk.filter(b => b.status === 'waiting').sort((a, b) => a.token - b.token)[0]
    if (next) { next.status = 'serving'; pr.serving = next.token } else pr.serving = 0
  })

  const skip = (id, noShow) => patch((pr, bk, d) => {
    const b = bk.find(x => x.id === id); if (!b) return false
    if (b.status === 'serving') pr.serving = 0
    b.status = noShow ? 'noshow' : 'cancelled'
    if (noShow) strike(d, b.customer, `Did not show up for token #${b.token} at ${pr.name}`)
  })

  const newDay = () => {
    if (!confirm('Start a new day? This clears the current queue and restarts tokens from 1.')) return
    patch((pr, bk) => {
      bk.forEach(b => { if (b.status === 'waiting' || b.status === 'serving') b.status = 'cancelled' })
      pr.nextToken = 1; pr.serving = 0
    })
  }

  const customerMenu = (b, c) => setMenu({ title: `${shortName(c?.name)} · token #${b.token}`, actions: [
    { label: '🚩 Report this customer', onClick: () => setReport({ targets: [{ userId: c.id, label: shortName(c.name), kind: 'customer' }] }) },
    { label: '⛔ Block this customer', danger: true, onClick: () => { if (confirm('Block this customer?')) { update(d => { toggleBlock(d, user.id, c.id) }); showToast('Customer blocked') } } },
  ] })

  const Dash = () => (
    <div className="p-3 space-y-3">
      <div>
        <p className="text-xs text-gray-500">{isDoctor ? '🩺 Doctor' : '✂️ Salon'} dashboard</p>
        <p className="font-bold text-lg wrap-any">{p.name}</p>
        <p className="text-sm text-gray-500">{p.tag}</p>
      </div>

      <button onClick={toggle} aria-pressed={p.available}
        className={`w-full rounded-2xl p-4 text-left text-white ${p.available ? 'bg-green-600' : 'bg-gray-500'}`}>
        <p className="text-xs opacity-80">Tap to change. Resets to "Not available" every night.</p>
        <p className="text-xl font-bold">{p.available ? '● Available now' : 'Not available'}</p>
        <p className="text-sm opacity-90">{p.available ? 'Customers can book tokens' : 'Customers cannot book'}</p>
      </button>

      <div className="grid grid-cols-3 gap-3">
        {[['Waiting', waiting], ['Now serving', p.serving ? `#${p.serving}` : '-'], ['Done today', done]].map(([l, v]) => (
          <div key={l} className="bg-white rounded-xl p-3 text-center"><p className="text-xs text-gray-500">{l}</p><p className="text-2xl font-bold">{v}</p></div>
        ))}
      </div>

      <button onClick={callNext} disabled={!queue.length} className="w-full bg-[#0e1f45] disabled:bg-gray-300 text-white font-semibold min-h-12 rounded-xl">
        {queue.some(b => b.status === 'serving') ? 'Finish & call next' : 'Call next customer'}
      </button>

      <h3 className="font-semibold">Queue ({queue.length})</h3>
      {queue.map(b => {
        const c = custOf(b.customer); const serving = b.status === 'serving'
        return (
          <div key={b.id} className={`bg-white rounded-xl p-3 ${serving ? 'border-l-4 border-green-600' : ''}`}>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center font-bold text-lg shrink-0">#{b.token}</div>
              <div className="flex-1 text-sm min-w-0">
                <p className="font-semibold truncate">{shortName(c?.name)} {serving && <span className="text-green-700 text-xs">· with you now</span>}</p>
                {b.note && <p className="text-gray-500 wrap-any">{b.note}</p>}
                <p className="text-xs text-gray-400">
                  {/* the full number is only usable when it is this customer's turn */}
                  {serving ? <a className="text-blue-600 underline" href={`tel:${c?.phone}`}>Call {maskPhone(c?.phone)}</a> : `Phone hidden until their turn`}
                </p>
              </div>
              <button aria-label="Options" className="w-9 h-9 text-lg shrink-0" onClick={() => customerMenu(b, c)}>⋯</button>
            </div>
            <div className="flex gap-2 mt-2">
              <button onClick={() => skip(b.id, false)} className="flex-1 text-xs border rounded-lg min-h-11">Skip</button>
              <button onClick={() => { if (confirm('Mark as no-show? The customer gets a strike.')) skip(b.id, true) }} className="flex-1 text-xs border border-red-300 text-red-600 rounded-lg min-h-11">No-show (strike)</button>
            </div>
          </div>
        )
      })}
      {!queue.length && <p className="text-center text-gray-400 py-6">Nobody in the queue</p>}

      <div className="bg-white rounded-xl p-3 space-y-2">
        <h3 className="font-semibold">Settings</h3>
        <div className="flex items-center justify-between text-sm gap-2">
          <span>{isDoctor ? 'Consultation fee ₹' : 'Starting price ₹'}</span>
          <input type="number" inputMode="numeric" value={p.fee} aria-label="Fee"
            onChange={e => { const n = toInt(e.target.value || 0, 0, 10000); if (n !== null) patch(pr => { pr.fee = n }) }}
            className="w-24 border rounded-lg px-2 py-2 text-center" />
        </div>
        <div className="flex items-center justify-between text-sm gap-2">
          <span>Minutes per customer</span>
          <input type="number" inputMode="numeric" value={p.avgMin} aria-label="Minutes per customer"
            onChange={e => { const n = toInt(e.target.value || 1, 1, 240); if (n !== null) patch(pr => { pr.avgMin = n }) }}
            className="w-24 border rounded-lg px-2 py-2 text-center" />
        </div>
        <button onClick={newDay} className="w-full border rounded-lg min-h-11 text-sm text-gray-600 mt-1">Start new day (reset tokens)</button>
      </div>
    </div>
  )

  return (
    <>
      {tab === 'dash' && Dash()}
      {tab === 'profile' && <Profile db={db} update={update} user={user} logout={logout} showToast={showToast} />}
      <Toast msg={toast} />
      {menu && <ActionSheet title={menu.title} actions={menu.actions} onClose={() => setMenu(null)} />}
      {report && <ReportSheet db={db} update={update} user={user} targets={report.targets} onClose={() => setReport(null)} showToast={showToast} />}
      <BottomNav tabs={[['dash', 'Dashboard'], ['profile', 'Me']]} tab={tab} setTab={setTab} badges={{ dash: waiting }} />
    </>
  )
}
