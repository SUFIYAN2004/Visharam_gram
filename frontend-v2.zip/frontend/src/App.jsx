import { useStore } from './store'
import { DEV_CONTACT } from './constants'
import Auth from './screens/Auth'
import Customer from './screens/Customer'
import Shopkeeper from './screens/Shopkeeper'
import Rider from './screens/Rider'
import Provider from './screens/Provider'
import Admin from './screens/Admin'

function Notice({ icon, title, text, logout }) {
  return (
    <div className="p-6 text-center">
      <div className="text-5xl mt-10 mb-3" aria-hidden="true">{icon}</div>
      <h2 className="text-xl font-bold text-[#0e1f45] mb-2">{title}</h2>
      <p className="text-gray-600 mb-6 wrap-any">{text}</p>
      <a href={`tel:${DEV_CONTACT.phone.replace(/\s/g, '')}`} className="inline-flex items-center justify-center bg-[#0e1f45] text-white font-semibold px-6 min-h-12 rounded-xl">📞 Call developer · {DEV_CONTACT.phone}</a>
      <div><button onClick={logout} className="mt-5 text-sm text-gray-500 underline min-h-11 px-4">Log out</button></div>
    </div>
  )
}

export default function App() {
  const { db, update, user, login, logout, device } = useStore()
  const props = { db, update, user, logout }

  let body
  if (!user) {
    body = <Auth db={db} update={update} login={login} device={device} />
  } else if (user.role !== 'admin' && (user.status === 'blocked' || db.blockedPhones.some(b => b.phone === user.phone) || db.blockedDevices.includes(device))) {
    body = <Notice icon="⛔" title="Account blocked" text={user.statusReason || 'This account cannot be used on Vishram Gram. If you think this is a mistake, please contact the developer.'} logout={logout} />
  } else if (user.status === 'pending') {
    body = <Notice icon="⏳" title="Waiting for approval" text="Thanks for signing up! The developer will verify your details and approve your account. You can use the app as soon as that is done." logout={logout} />
  } else if (user.role === 'admin') body = <Admin {...props} />
  else if (user.role === 'customer') body = <Customer {...props} />
  else if (user.role === 'shopkeeper') body = <Shopkeeper {...props} />
  else if (user.role === 'rider') body = <Rider {...props} />
  else if (user.role === 'doctor' || user.role === 'salon') body = <Provider {...props} />
  else body = <Auth db={db} update={update} login={login} device={device} />

  return (
    <div className="max-w-md mx-auto app-shell bg-gray-100 relative shadow-sm">
      <header className="sticky top-0 z-10 bg-white border-b pt-safe">
        <div className="px-4 py-2 flex justify-between items-center gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <img src="/logo-icon.svg" alt="Vishram Gram" className="h-10 w-10 object-contain shrink-0" />
            <h1 className="text-base min-[360px]:text-lg font-extrabold tracking-wide text-[#0e1f45] truncate">VISHRAM GRAM</h1>
          </div>
          <span className="text-xs text-gray-500 shrink-0 hidden min-[350px]:block">{user ? <span className="capitalize">{user.role === 'shopkeeper' ? 'shop' : user.role}</span> : '📍 Melvisharam'}</span>
        </div>
      </header>
      {user && user.status === 'review' && user.role !== 'customer' && user.role !== 'admin' && (
        <p role="alert" className="mx-3 mt-3 text-sm bg-amber-50 text-amber-800 rounded-xl p-3 wrap-any">
          ⚠️ Your account is under review ({user.statusReason || 'please wait'}). You are hidden from customers until the developer checks it. Call {DEV_CONTACT.phone} to sort this out.
        </p>
      )}
      {body}
    </div>
  )
}
