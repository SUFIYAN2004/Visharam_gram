// ======================================================================
//  RULES & SETTINGS  (edit here)
//  Everything in this app runs in the browser for now, so these rules are
//  enforced in the UI only. When we build the backend, the SAME rules move
//  to the server, where nobody can bypass them.
// ======================================================================

export const STEPS = ['placed', 'accepted', 'ready', 'picked_up', 'delivered']
export const ACTIVE = ['placed', 'accepted', 'ready', 'picked_up']
export const LABEL = {
  placed: 'Waiting for shop', accepted: 'Shop accepted', ready: 'Ready for pickup',
  picked_up: 'On the way 🛵', delivered: 'Delivered ✅', rejected: 'Rejected by shop',
  cancelled: 'Cancelled', expired: 'Shop did not respond', failed: 'Delivery failed',
}
export const DEAD = ['rejected', 'cancelled', 'expired', 'failed']
export const DELIVERY_FEE = 20

// Delivery areas of Melvisharam. EDIT these to your real areas.
export const AREAS = ['Main Bazaar', 'Bus Stand Road', 'Market Street', 'Railway Road', 'Other area (write below)']

export const LIMITS = {
  maxActiveOrders: 3,      // orders a customer can have in progress
  maxQtyPerItem: 10,
  firstOrderMax: 2000,     // ₹ cap on a customer's first cash order
  orderCooldownMs: 30000,  // wait between two orders
  placedExpiryMin: 10,     // shop must answer within this time
  riderMaxActive: 2,
  maxReportsPerDay: 5,
  strikesToReview: 3,      // no-shows / failed deliveries before the account is paused
  reviewAtReports: 3,      // different people reporting the same account -> paused for admin review
  maxProductsPerShop: 80,
  cashOverdueHours: 24,    // rider must hand over shop cash within this time
  otpMaxFails: 3,
  otpLockMin: 5,
  otpCooldownSec: 30,
  otpPerHour: 5,
  sessionDays: 7,
  adminIdleMin: 15,
}

// Words shops may not use in product names or captions (starting list, add more).
export const BANNED_WORDS = [
  'cigarette', 'tobacco', 'gutka', 'gutkha', 'hans ', 'ganja', 'weed', 'charas', 'marijuana',
  'alcohol', 'liquor', 'beer', 'whisky', 'whiskey', 'vodka', 'brandy', 'toddy', 'arrack',
  'pistol', 'gun ', 'weapon', 'explosive', 'bomb', 'knife attack',
  'tramadol', 'codeine', 'alprazolam', 'steroid', 'abortion pill',
]

// ----- Admin (the developer). CHANGE BOTH BEFORE ANY REAL USE. -----
// Default demo passcode is:  Vishram@2026
// To make your own hash run this in a terminal:
//   node -e "console.log(require('crypto').createHash('sha256').update('YOUR-NEW-PASSCODE').digest('hex'))"
export const ADMIN_PHONES = ['9000000000']
export const ADMIN_PASS_HASH = '640c9d19e76a905dcfa2a012ebc61d7e7962053c30fcc78440ac41d8aa83dc17'

// Shown to users in Profile -> "Contact developer"
export const DEV_CONTACT = { phone: '90000 00000', email: 'developer@example.com' }

export const REPORT_REASONS = {
  customer: ['Fake or prank order', 'Abusive or harassing', 'Refused order / did not pay', 'Did not show up', 'Other'],
  shop: ['Wrong or fake product', 'Overcharging', 'Sells banned items', 'Rude behaviour', 'Fake shop or impersonation', 'Other'],
  rider: ['Asked for extra money', 'Rude behaviour', 'Did not deliver', 'Damaged or wrong delivery', 'Suspicious behaviour', 'Other'],
  provider: ['Fake doctor or salon', 'Wrong availability shown', 'Overcharging', 'Rude behaviour', 'Other'],
  bug: ['App problem', 'Wrong information (timings etc.)', 'Suggestion', 'Other'],
}
