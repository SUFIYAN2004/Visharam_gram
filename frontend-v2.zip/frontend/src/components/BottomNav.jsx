const I = {
  home: <path d="M3 11l9-8 9 8v9a1 1 0 01-1 1h-5v-6H9v6H4a1 1 0 01-1-1z" />,
  search: <><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" /></>,
  cart: <><path d="M3 4h2l2.5 11h10L20 7H6" /><circle cx="9" cy="20" r="1.3" /><circle cx="17" cy="20" r="1.3" /></>,
  orders: <><path d="M21 8l-9-5-9 5v8l9 5 9-5z" /><path d="M3 8l9 5 9-5M12 13v8" /></>,
  dash: <><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></>,
  products: <><rect x="3" y="3" width="18" height="18" rx="3" /><path d="M12 8v8M8 12h8" /></>,
  services: <><circle cx="12" cy="12" r="9" /><path d="M12 7v10M7 12h10" /></>,
  profile: <><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4 4-6 8-6s8 2 8 6" /></>,
  check: <><circle cx="12" cy="12" r="9" /><path d="M8 12.5l3 3 5-6" /></>,
  flag: <><path d="M5 21V4" /><path d="M5 4h12l-2 4 2 4H5" /></>,
  users: <><circle cx="9" cy="8" r="3.5" /><path d="M2.5 20c0-3.5 3-5.5 6.5-5.5s6.5 2 6.5 5.5" /><path d="M16 4.5a3.5 3.5 0 010 7M18.5 14.8c2 .7 3 2.3 3 5.2" /></>,
  more: <><circle cx="5" cy="12" r="1.5" /><circle cx="12" cy="12" r="1.5" /><circle cx="19" cy="12" r="1.5" /></>,
}

export default function BottomNav({ tabs = [], tab, setTab, badges = {} }) {
  return (
    <nav aria-label="Main" className="fixed bottom-0 inset-x-0 max-w-md mx-auto bg-white border-t z-20 pb-safe"
      style={{ display: 'grid', gridTemplateColumns: `repeat(${Math.max(1, tabs.length)}, minmax(0, 1fr))` }}>
      {tabs.map(([id, label, icon]) => (
        <button key={id} onClick={() => setTab(id)} aria-current={tab === id ? 'page' : undefined}
          className={`min-h-[52px] py-2 flex flex-col items-center justify-center relative ${tab === id ? 'text-[#0e1f45]' : 'text-gray-400'}`}>
          <svg width="23" height="23" viewBox="0 0 24 24" fill={tab === id && !['check', 'flag', 'users', 'more'].includes(icon || id) ? 'currentColor' : 'none'}
            stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            {I[icon || id]}
          </svg>
          <span className="text-[10px] mt-0.5 leading-none truncate max-w-full px-0.5">{label}</span>
          {badges[id] > 0 && (
            <span className="absolute top-1 left-1/2 ml-2 bg-red-500 text-white text-[10px] min-w-4 h-4 px-1 rounded-full flex items-center justify-center">
              {badges[id] > 99 ? '99+' : badges[id]}
            </span>
          )}
        </button>
      ))}
    </nav>
  )
}
