import { useState, useEffect } from 'react'

// Shows the ads the developer manages in the Admin panel
export default function AdBanner({ ads = [] }) {
  const list = ads.filter(a => a.active)
  const [i, setI] = useState(0)
  useEffect(() => {
    if (list.length < 2) return
    const t = setInterval(() => setI(x => x + 1), 4500)
    return () => clearInterval(t)
  }, [list.length])
  if (!list.length) return null
  const a = list[i % list.length]
  return (
    <div className="px-3 pt-3">
      <div key={a.id} className="rounded-2xl p-4 text-white relative overflow-hidden" style={{ background: `linear-gradient(135deg, ${a.c1}, ${a.c2})` }}>
        <span className="absolute top-2 right-3 text-[10px] bg-black/30 px-2 py-0.5 rounded-full">Ad</span>
        <p className="font-bold text-base pr-8 wrap-any">{a.title}</p>
        <p className="text-sm opacity-90 mt-1 wrap-any">{a.text}</p>
        {a.cta && <span className="inline-block mt-3 text-xs font-semibold bg-white text-slate-900 px-3 py-1 rounded-full">{a.cta}</span>}
        {list.length > 1 && (
          <div className="flex gap-1 mt-3">
            {list.map((x, j) => <span key={x.id} className={`h-1.5 rounded-full ${j === i % list.length ? 'w-4 bg-white' : 'w-1.5 bg-white/50'}`} />)}
          </div>
        )}
      </div>
    </div>
  )
}
