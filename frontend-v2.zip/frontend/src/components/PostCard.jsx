export default function PostCard({ p, shop, liked, onLike, onAdd, onShop, qty }) {
  return (
    <article className="bg-white mb-3">
      <button type="button" className="flex w-full items-center gap-3 px-3 py-2.5 text-left" onClick={onShop}>
        <img src={shop.logo} alt="" decoding="async" className="w-9 h-9 rounded-full object-cover ring-2 ring-[#e0b85c] ring-offset-2" />
        <span className="flex-1 leading-tight min-w-0">
          <span className="block font-semibold text-sm truncate">{shop.name}</span>
          <span className="block text-xs text-gray-500">{shop.cat} · Melvisharam</span>
        </span>
        <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full whitespace-nowrap">10 min</span>
      </button>

      <div className="relative" onDoubleClick={onLike}>
        <img src={p.img} alt={p.name} loading="lazy" decoding="async" className="w-full aspect-square object-cover bg-gray-100" />
        <span className="absolute bottom-3 left-3 bg-[#0e1f45]/90 text-[#e0b85c] font-semibold px-3 py-1 rounded-full text-sm">₹{p.price}</span>
        {p.stock <= 5 && p.stock > 0 && (
          <span className="absolute top-3 right-3 bg-red-500 text-white text-xs px-2 py-1 rounded-full">Only {p.stock} left</span>
        )}
      </div>

      <div className="flex items-center gap-3 px-3 pt-2">
        <button onClick={onLike} aria-label={liked ? 'Unlike' : 'Like'} aria-pressed={liked}
          className="text-2xl w-11 h-11 flex items-center justify-center active:scale-125 transition">{liked ? '❤️' : '🤍'}</button>
        <button disabled={!p.stock} onClick={onAdd}
          className="ml-auto bg-[#0e1f45] disabled:bg-gray-300 text-white text-sm font-semibold px-5 min-h-11 rounded-lg active:scale-95 transition">
          {!p.stock ? 'Sold out' : qty ? `Add more (${qty})` : 'Add to cart'}
        </button>
      </div>

      <div className="px-3 pb-4 pt-1 text-sm wrap-any">
        <p className="font-semibold">{p.likes + (liked ? 1 : 0)} likes</p>
        <p><b>{shop.name}</b> {p.name} — {p.cap}</p>
      </div>
    </article>
  )
}
