import { useEffect } from 'react'

// Bottom sheet that works on every phone (respects the iPhone home bar)
export default function Sheet({ title, onClose, children }) {
  useEffect(() => {
    const onKey = e => { if (e.key === 'Escape') onClose() }
    addEventListener('keydown', onKey)
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { removeEventListener('keydown', onKey); document.body.style.overflow = prev }
  }, [onClose])

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="sheet-in relative w-full max-w-md bg-white rounded-t-3xl px-4 pt-3 pb-safe max-h-[88vh] overflow-y-auto">
        <div className="w-10 h-1 bg-gray-300 rounded-full mx-auto mb-3" />
        {title && <h3 className="font-bold text-lg mb-3">{title}</h3>}
        <div className="pb-4">{children}</div>
      </div>
    </div>
  )
}

// A list of tappable actions, e.g. "Report" / "Block"
export function ActionSheet({ title, actions, onClose }) {
  return (
    <Sheet title={title} onClose={onClose}>
      <div className="space-y-2">
        {actions.filter(Boolean).map(a => (
          <button key={a.label} onClick={() => { onClose(); a.onClick() }}
            className={`w-full text-left px-4 py-3.5 rounded-xl border text-base ${a.danger ? 'text-red-600 border-red-200' : 'border-gray-200'}`}>
            {a.label}
          </button>
        ))}
        <button onClick={onClose} className="w-full px-4 py-3.5 rounded-xl bg-gray-100 text-base font-semibold">Close</button>
      </div>
    </Sheet>
  )
}
