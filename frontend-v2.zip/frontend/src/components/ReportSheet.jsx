import { useState } from 'react'
import Sheet from './Sheet'
import { REPORT_REASONS, DEV_CONTACT } from '../constants'
import { cleanLong } from '../security'
import { checkReport, addReport } from '../store'

// targets: [{ userId, label, kind }]  (kind picks the list of reasons). Use kind 'bug' + empty targets to contact the developer.
export default function ReportSheet({ db, update, user, targets = [], orderId = null, onClose, showToast }) {
  const [ti, setTi] = useState(0)
  const [reason, setReason] = useState('')
  const [text, setText] = useState('')
  const [err, setErr] = useState('')
  const t = targets[ti]
  const kind = t ? t.kind : 'bug'

  const submit = () => {
    const payload = { from: user.id, kind, target: t ? t.userId : null, orderId, reason, text: cleanLong(text, 500) }
    const e = checkReport(db, payload)
    if (e) return setErr(e)
    update(d => { addReport(d, payload) })
    showToast('Sent to the developer. Thank you')
    onClose()
  }

  return (
    <Sheet title={t ? 'Report to developer' : 'Contact developer'} onClose={onClose}>
      {targets.length > 1 && (
        <div className="flex gap-2 mb-3">
          {targets.map((x, i) => (
            <button key={x.userId} onClick={() => { setTi(i); setReason('') }}
              className={`flex-1 py-2 rounded-xl border text-sm ${i === ti ? 'bg-[#0e1f45] text-white border-[#0e1f45]' : ''}`}>{x.label}</button>
          ))}
        </div>
      )}
      {t && targets.length === 1 && <p className="text-sm text-gray-600 mb-3">About: <b>{t.label}</b></p>}

      <p className="text-xs text-gray-500 mb-1">What happened?</p>
      <div className="flex flex-wrap gap-2 mb-3">
        {REPORT_REASONS[kind].map(r => (
          <button key={r} onClick={() => setReason(r)}
            className={`px-3 py-2 rounded-full border text-sm ${reason === r ? 'bg-[#0e1f45] text-white border-[#0e1f45]' : 'bg-white'}`}>{r}</button>
        ))}
      </div>
      <textarea value={text} onChange={e => setText(e.target.value)} rows={3} maxLength={500}
        placeholder="Tell us more (optional). Do not share OTP or PIN." className="w-full border rounded-xl p-3 outline-none mb-1" />
      <p className="text-[11px] text-gray-400 mb-3">The developer reviews every report. False reports can lead to your own account being blocked.</p>
      {err && <p className="text-sm text-red-600 mb-2">{err}</p>}
      <button onClick={submit} disabled={!reason}
        className="w-full bg-[#0e1f45] disabled:bg-gray-300 text-white font-semibold py-3 rounded-xl">Send report</button>
      <p className="text-xs text-gray-500 text-center mt-3">Urgent? Call the developer: <a className="text-blue-600" href={`tel:${DEV_CONTACT.phone.replace(/\s/g, '')}`}>{DEV_CONTACT.phone}</a></p>
    </Sheet>
  )
}
