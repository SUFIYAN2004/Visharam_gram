import { useState, useRef, useEffect, useCallback } from 'react'

export function useToast() {
  const [msg, setMsg] = useState('')
  const timer = useRef(null)
  const show = useCallback(m => {
    setMsg(m); clearTimeout(timer.current)
    timer.current = setTimeout(() => setMsg(''), 2400)
  }, [])
  useEffect(() => () => clearTimeout(timer.current), [])
  return [msg, show]
}

export function Toast({ msg }) {
  if (!msg) return null
  return (
    <div role="status" aria-live="polite"
      className="toast-pos fixed left-1/2 -translate-x-1/2 max-w-[92vw] bg-gray-900 text-white text-sm px-4 py-2 rounded-full z-[60] text-center shadow-lg">
      {msg}
    </div>
  )
}
