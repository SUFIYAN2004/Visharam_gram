# Vishram Gram: safety and security notes

## What the app enforces now (in the browser)
- Shops, riders, doctors and salons need developer approval before they go live.
- Customer phone/address are hidden: shops see a short name only; riders see the area until pickup
  and a masked number after; doctors/salons see the number only when it is the customer's turn.
- Delivery PIN: the customer reads a 4-digit PIN to the rider. 3 wrong tries lock the order and alert the developer.
- Cash settlement: riders owe shops the item money; shops tick "Received"; overdue after 24 h blocks new pickups.
- Report to developer, block users, auto-pause an account after reports from 3 different people,
  strikes for no-shows and failed deliveries, blocked phone numbers and devices.
- Limits: 3 active orders, max 10 per item, first order up to Rs 2000, 30 s between orders,
  one active token for doctors/salons, banned-item words, 5 reports/day.
- OTP: 30 s resend wait, 5 per hour, 3 wrong tries lock the number for 5 min.
- All text input is cleaned and length-limited; photos are re-encoded (this removes GPS data).
- Production build adds a Content-Security-Policy (see vite.config.js).
- Admin: separate login with passcode (hashed), auto sign-out after 15 idle minutes, every action is logged.

## What needs the backend (cannot be made safe in the browser)
- Anyone who opens DevTools can edit the data on their own phone. Rules must be re-checked on the server.
- Real SMS OTP (OTP is 1234 now) and real login sessions.
- The admin passcode hash is visible in the code; admin login must move to the server.
- Blocked devices can be dodged by clearing browser data; the server will track accounts and phone numbers properly.
- Masked calling (so riders never see a real number) needs a calling service.
- Shared data between phones: today each phone has its own copy.

## Before real use, change these in src/constants.js
- ADMIN_PHONES and ADMIN_PASS_HASH (default passcode is Vishram@2026)
- DEV_CONTACT, AREAS, and the real mosque times in src/data/static.js
