import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// Content-Security-Policy is added ONLY in production builds (npm run build),
// because the dev server needs inline scripts for hot reload.
// When you add Cloudinary / your API later, add their hosts to img-src / connect-src.
const CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob: https://picsum.photos https://fastly.picsum.photos",
  "font-src 'self'",
  "connect-src 'self'",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
].join('; ')

const securityHeaders = {
  name: 'vg-csp',
  apply: 'build',
  transformIndexHtml: html =>
    html.replace('</head>', `    <meta http-equiv="Content-Security-Policy" content="${CSP}" />\n  </head>`),
}

export default defineConfig({
  plugins: [react(), tailwindcss(), securityHeaders],
})
